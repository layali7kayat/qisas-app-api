# Dramio V32 — Player, Notification Intent, and Coming Soon Admin

## Android app
- Selecting an episode row in the story player now switches the ExoPlayer media item to that exact episode, starts playback, updates the current episode state, and scrolls back to the player controls.
- Character-support reminders now trigger once per story after the user starts two distinct episodes of that story. Removed the old episode 9, episode 10, and final-episode reminder triggers.
- Character-support reminders open the actors/characters page filtered to the listened-to story.
- New-episode notifications (`new_episode`) open the corresponding story details page instead of the actors page. Comment-reply notifications open the related story details/comments route when available.
- Character-support reminders are also written to the existing in-app notification inbox. The existing red unread badge refreshes while the app remains open.
- Existing story-bell subscriptions and their new-episode notification delivery remain separate from character-support reminders.

## Admin panel
- Added a dedicated **قريباً** tab to manage stories that have no main MP3 and no published MP3 parts.
- Admin can add a story to Coming Soon, edit its details, and delete it from that tab.
- Adding the first MP3 part moves the story out of Coming Soon and restores its originally selected categories.

## Cloudflare Worker
- Admin catalog now returns whether a story has published MP3 parts, allowing the Coming Soon tab to distinguish stories with audio parts.
- Public catalog consistently places stories with no MP3 episodes in Coming Soon, and restores selected categories once an MP3 part exists.
- Existing new-episode push notifications continue targeting only users subscribed to that story.

## Validation
- `node --check backend/cloudflare/worker.js` passed.
- Android Gradle compilation could not be run in this environment because the supplied project does not include `gradlew` and no system Gradle installation is available.
