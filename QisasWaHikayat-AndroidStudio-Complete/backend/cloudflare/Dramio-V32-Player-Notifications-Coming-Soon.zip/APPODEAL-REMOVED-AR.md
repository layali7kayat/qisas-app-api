# Dramio — إزالة Appodeal والوساطة

- تمت إزالة Appodeal SDK وجميع محولاته وشبكاته من المشروع.
- تمت إزالة مستودع Appodeal من إعدادات Gradle.
- يعتمد المشروع على Google Mobile Ads SDK فقط، دون شركاء وساطة أو AdMob mediation adapters.
- مواضع Banner وNative وInterstitial محفوظة في الواجهات.
- جميع طلبات الإعلانات معطلة في Debug وRelease حاليًا عبر `ADS_PRODUCTION_ENABLED=false`.
- لا تتم تهيئة MobileAds ولا تحميل أي إعلان ولا عرض أي إعلان إلى أن يُفعّل Release صراحةً بعد عودة حساب AdMob إلى حالة نشطة.
- لا يوجد إعلان Rewarded نشط؛ ميزة المكافأة تعود بحالة غير متاح دون طلب إعلان.

## معرّفات AdMob

- App ID: `ca-app-pub-8926612269781002~3209597128`
- Banner: `ca-app-pub-8926612269781002/8133025827`
- Native: `ca-app-pub-8926612269781002/6968117968`
- Interstitial: `ca-app-pub-8926612269781002/9594281306`

## إعادة التفعيل لاحقًا

بعد انتهاء تعليق AdMob والتأكد من أن الحساب نشط ومسموح له بعرض الإعلانات، يمكن تفعيل إعلانات Release فقط بتغيير `ADS_PRODUCTION_ENABLED` إلى `true` داخل `buildTypes.release`. اترك Debug على `false`، ولا تختبر بالنقر على الإعلانات الحقيقية.
