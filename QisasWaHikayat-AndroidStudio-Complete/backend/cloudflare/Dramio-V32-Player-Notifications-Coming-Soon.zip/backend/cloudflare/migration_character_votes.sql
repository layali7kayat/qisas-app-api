-- Schema must match the Cloudflare Worker /api/character-votes and /api/character-vote routes.
CREATE TABLE IF NOT EXISTS character_votes (
  story_id TEXT NOT NULL,
  character_id TEXT NOT NULL CHECK(character_id IN ('character_one','character_two','character_three')),
  voter_id TEXT NOT NULL,
  vote INTEGER NOT NULL CHECK(vote IN (-1,1)),
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(story_id, character_id, voter_id)
);
CREATE INDEX IF NOT EXISTS idx_character_votes_story_character
ON character_votes(story_id, character_id);
