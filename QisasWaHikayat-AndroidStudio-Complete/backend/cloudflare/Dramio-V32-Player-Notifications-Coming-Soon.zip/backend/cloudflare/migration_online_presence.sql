-- Live online-user counter. Rows older than 10 minutes are pruned by the Worker.
CREATE TABLE IF NOT EXISTS online_presence (
  visitor_id TEXT PRIMARY KEY,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_online_presence_last_seen ON online_presence(last_seen);
