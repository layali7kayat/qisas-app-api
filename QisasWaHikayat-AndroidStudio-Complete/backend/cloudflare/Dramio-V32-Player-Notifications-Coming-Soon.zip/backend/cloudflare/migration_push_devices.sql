-- Persistent device tokens used for notifications when someone replies to a comment.
CREATE TABLE IF NOT EXISTS push_devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  visitor_id TEXT NOT NULL,
  fcm_token TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(visitor_id, fcm_token)
);
CREATE INDEX IF NOT EXISTS idx_push_devices_visitor ON push_devices(visitor_id);
