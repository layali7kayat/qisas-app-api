-- Dramio guest-to-Google XP identity links. Safe to run more than once.
CREATE TABLE IF NOT EXISTS engagement_identity_links (
  visitor_id TEXT PRIMARY KEY,
  account_visitor_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_engagement_identity_account ON engagement_identity_links(account_visitor_id);
