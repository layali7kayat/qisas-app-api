-- Dramio story analytics: aggregate opens, listening, completion and favorites.
CREATE TABLE IF NOT EXISTS story_analytics_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  story_id INTEGER NOT NULL,
  episode_id TEXT NOT NULL DEFAULT '',
  visitor_id TEXT NOT NULL DEFAULT '',
  event_type TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_story_analytics_story_time
  ON story_analytics_events(story_id, created_at);
