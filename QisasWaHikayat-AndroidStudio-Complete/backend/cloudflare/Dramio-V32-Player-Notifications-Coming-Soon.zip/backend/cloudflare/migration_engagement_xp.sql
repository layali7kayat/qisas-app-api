-- Dramio engagement XP and leaderboard
CREATE TABLE IF NOT EXISTS engagement_profiles (
  visitor_id TEXT PRIMARY KEY,
  display_name TEXT NOT NULL DEFAULT 'مستخدم Dramio',
  avatar_key TEXT NOT NULL DEFAULT '',
  xp INTEGER NOT NULL DEFAULT 0,
  is_member INTEGER NOT NULL DEFAULT 0,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS engagement_events (
  visitor_id TEXT NOT NULL,
  event_key TEXT NOT NULL,
  event_type TEXT NOT NULL,
  points INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(visitor_id, event_key)
);

CREATE INDEX IF NOT EXISTS idx_engagement_xp ON engagement_profiles(xp DESC, last_seen ASC);
