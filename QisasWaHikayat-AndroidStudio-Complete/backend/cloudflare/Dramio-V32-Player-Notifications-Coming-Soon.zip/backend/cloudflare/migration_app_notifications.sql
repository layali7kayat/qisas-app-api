-- Dramio in-app admin broadcasts
CREATE TABLE IF NOT EXISTS app_notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'general',
  sender_name TEXT NOT NULL DEFAULT 'Dramio',
  sender_avatar TEXT NOT NULL DEFAULT 'app',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
