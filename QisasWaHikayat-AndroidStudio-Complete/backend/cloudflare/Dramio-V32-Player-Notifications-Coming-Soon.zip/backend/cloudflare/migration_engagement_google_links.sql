-- Link each Google account to a canonical Dramio identity. Safe to run more than once.
CREATE TABLE IF NOT EXISTS engagement_google_links (
  google_sub TEXT PRIMARY KEY,
  visitor_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_engagement_google_visitor ON engagement_google_links(visitor_id);
