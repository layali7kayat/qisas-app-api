# ربط تقارير AdMob مع Dramio (OAuth)

هذا التحديث يضيف مسارات OAuth وتقارير AdMob إلى Cloudflare Worker. لا يفعّل الإعلانات ولا يحمّل SDK أو يطلب ظهور إعلان.

## 1) إعدادات Cloudflare Worker Secrets

في `qisas-app-api` > Settings > Variables and Secrets أضف القيم التالية:

| الاسم | النوع | القيمة |
|---|---|---|
| `ADMOB_OAUTH_CLIENT_ID` | Secret | OAuth Client ID من Google Auth Platform |
| `ADMOB_OAUTH_CLIENT_SECRET` | Secret | Client Secret الجديد |
| `ADMOB_TOKEN_ENCRYPTION_KEY` | Secret | مفتاح AES-256 عشوائي بصيغة Base64، 32 بايت قبل الترميز |
| `ADMOB_PUBLISHER_ID` | Secret أو Variable | معرّف الناشر `pub-...` كما يظهر في AdMob |

لإنشاء مفتاح تشفير عشوائي محلياً (لا تشاركه): `openssl rand -base64 32`.

## 2) Redirect URI في Google Auth Platform

أضف هذا العنوان حرفياً إلى Authorized redirect URIs في عميل OAuth الجديد:

`https://qisas-app-api.layali-7kayat-719.workers.dev/api/admob/oauth/callback`

OAuth scope المستخدم: `https://www.googleapis.com/auth/admob.report`.

## 3) النشر

انشر `backend/cloudflare/worker.js` على Worker `qisas-app-api`. لا يوجد ترحيل D1 يدوي مطلوب؛ ينشئ Worker جدولي `admob_oauth_credentials` و`admob_oauth_states` عند أول استخدام.

## 4) بدء الربط

تبدأ لوحة الإدارة طلب POST إلى `/api/admin/admob/oauth/start` مع ترويسة `Authorization: Bearer <admin Google ID token>`. يرجع المسار `authorization_url`؛ افتحه في متصفح، ثم اختر حساب Google الذي يملك حساب AdMob ووافق على الصلاحية.

بعد العودة إلى صفحة callback ستظهر رسالة نجاح. يتم حفظ refresh token مشفراً باستخدام AES-GCM في D1؛ لا يُعاد إظهاره في أي استجابة.

## 5) جلب التقرير

GET `/api/admin/admob/report?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD` مع ترويسة Bearer الخاصة بالمدير. إذا لم تُحدد التواريخ، يستخدم آخر 30 يوماً. يعيد التقرير على مستوى DATE وAPP وAD_UNIT وبعملة USD.

## حدود مهمة

- لا يُفعّل هذا التحديث الإعلانات إطلاقاً.
- إذا كان حساب AdMob موقوفاً أو كانت تقارير الحساب غير متاحة، قد ترفض Google طلب التقرير؛ سيعرض Worker رمز الحالة وتفاصيل الخطأ المختصرة.
- تقارير AdMob القياسية لا تحدد القصة التي كان المستخدم يستمع إليها عند ظهور الإعلان. لذلك لا يمكن نسب دخل كل قصة اعتماداً على هذا التقرير وحده. يلزم لاحقاً استقبال impression-level paid events من SDK، وهذا غير مفعّل في هذا التحديث.
- OAuth consent screen قد يقيّد عدد المستخدمين أثناء وضع Testing أو قبل التحقق. استخدم حساب المالك المخوّل.
- لا تضع Client Secret أو Refresh Token داخل تطبيق Android أو مستودع Git.
