# إعلان مكافآت XP في Dramio — إصدار SSV

معرّف وحدة الإعلان: `ca-app-pub-8926612269781002/2960783714`.

يعين التطبيق `ServerSideVerificationOptions` على الإعلان قبل عرضه، ويرسل `visitorId` في معامل `user_id`. لا يرسل التطبيق طلب منح XP عند callback المحلي؛ الخادم وحده يمنح 10 XP بعد التحقق من توقيع AdMob SSV.

المسار: `/api/admob/ssv`.

قواعد التحقق: توقيع Google ECDSA صحيح، ووحدة الإعلان مطابقة، و`reward_amount=10`، و`reward_item=XP`، و`user_id` صالح. يستخدم الخادم `transaction_id` كمفتاح فريد لمنع التكرار.

راجع `ADMOB-SSV-SETUP-AR.md` لإعداد رابط callback في AdMob ونشر Worker واختباره.
