# Dramio v17.0 — سجل التحديث

## 1) عزل إعلانات الاختبار عن إعلانات الإنتاج

- في نسخة Debug يتم استخدام معرّف تطبيق Google التجريبي وجميع وحدات Google التجريبية فقط.
- يشمل ذلك Banner وNative وInterstitial وRewarded.
- لا يُسمح باستخدام معرّفات AdMob الحقيقية إلا عندما يكون البناء Release ويكون `ADS_PRODUCTION_ENABLED=true`.
- حتى إذا تم ضبط المفتاح بالخطأ على true في Debug، فإن `BuildConfig.DEBUG` يجبر التطبيق على استخدام وحدات الاختبار.
- `ADS_PRODUCTION_ENABLED` مضبوط صراحةً إلى false في Debug وtrue في Release داخل `app/build.gradle.kts`.

## 2) قصص «قد يعجبك أيضاً»

- يتم استبعاد القصة الحالية.
- يتم خلط بقية القصص عشوائياً واختيار 6 قصص.
- يتم تثبيت الاختيار أثناء عرض المشغل حتى لا تتغير القائمة مع كل إعادة رسم للواجهة.
- عند فتح مشغل قصة أخرى، يتم اختيار مجموعة عشوائية جديدة.

## معلومات الإصدار

- applicationId: `ap4221554.cyq` (لم يتغير)
- versionCode: `17`
- versionName: `17.0`

## ملاحظة الاختبار

لم تتوفر بيئة Gradle قابلة للتشغيل داخل بيئة إعداد الحزمة، لذلك لم يتم تأكيد نجاح assembleDebug/assembleRelease هنا. افتح المشروع في Android Studio، نفّذ Gradle Sync ثم Build > Make Project قبل اعتماد الإصدار.


## تحديث أمان AdMob (12 نوفمبر 2026)
- تعطيل تهيئة Mobile Ads SDK في Debug وRelease.
- منع جميع طلبات وتحميلات Banner وNative وInterstitial وRewarded مؤقتاً.
- الاحتفاظ بمعرّفات الإنتاج وإعدادات المكافآت وSSV دون حذف.
