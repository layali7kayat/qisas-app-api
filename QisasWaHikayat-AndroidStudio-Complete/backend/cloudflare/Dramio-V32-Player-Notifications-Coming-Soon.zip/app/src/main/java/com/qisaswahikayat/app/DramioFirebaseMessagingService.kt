package com.qisaswahikayat.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class DramioFirebaseMessagingService : FirebaseMessagingService() {
    /**
     * Firebase may rotate the device token while the app is not open.
     * Persist it immediately and re-register it against the current visitor.
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val prefs = getSharedPreferences("qisas_native", MODE_PRIVATE)
        val previousToken = prefs.getString("dramio_fcm_token", null)
        prefs.edit()
            .putString("dramio_previous_fcm_token", previousToken)
            .putString("dramio_fcm_token", token)
            .apply()

        val visitorId = prefs.getString("visitor_id", null)?.takeIf { it.isNotBlank() }
            ?: return // MainActivity will register the latest Firebase token after creating visitor_id.

        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("$API_BASE/api/notifications/register").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 15000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject()
                    .put("visitor_id", visitorId)
                    .put("fcm_token", token)
                if (!previousToken.isNullOrBlank() && previousToken != token) {
                    payload.put("previous_fcm_token", previousToken)
                }
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                if (code !in 200..299) {
                    val error = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    Log.e("DramioFCM", "Token refresh registration failed: HTTP $code $error")
                } else {
                    prefs.edit().remove("dramio_previous_fcm_token").apply()
                }
            } catch (e: Exception) {
                Log.e("DramioFCM", "Unable to register refreshed FCM token", e)
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.data["title"] ?: message.notification?.title ?: "حلقة جديدة في Dramio"
        val body = message.data["body"] ?: message.notification?.body ?: "تم نشر حلقة جديدة من قصة تتابعها"
        // Use a new channel ID so Android applies the updated HIGH importance
        // even on devices where the previous channel was already created.
        val channelId = "dramio_story_updates_v2"
        // Keep a small in-app inbox so the home notification badge reflects replies and new episodes.
        runCatching {
            val prefs = getSharedPreferences("qisas_native", MODE_PRIVATE)
            val old = org.json.JSONArray(prefs.getString("dramio_notifications", "[]") ?: "[]")
            val entry = org.json.JSONObject().put("title", title).put("body", body)
                .put("time", java.text.SimpleDateFormat("MMM dd, yyyy  hh:mm a", java.util.Locale.US).format(java.util.Date()))
                .put("type", message.data["type"] ?: "story_update")
                .put("story_id", message.data["story_id"] ?: "")
                .put("comment_id", message.data["comment_id"] ?: "")
            val updated = org.json.JSONArray().put(entry)
            for (i in 0 until minOf(old.length(), 49)) updated.put(old.getJSONObject(i))
            prefs.edit().putString("dramio_notifications", updated.toString())
                .putInt("dramio_unread_notifications", prefs.getInt("dramio_unread_notifications", 0) + 1).apply()
        }

        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(channelId, "إشعارات Dramio", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "إشعارات القصص والحلقات الجديدة والتنبيهات"
                setShowBadge(true)
                enableVibration(true)
            }
        )
        val storyId = message.data["story_id"].orEmpty()
        val notificationType = message.data["type"].orEmpty()
        val notificationId = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            when (notificationType) {
                "new_episode" -> {
                    putExtra("open_story_detail_from_notification", true)
                    putExtra("notification_story_id", storyId)
                }
                "character_support" -> {
                    putExtra("open_actors_from_notification", true)
                    putExtra("support_story_id", storyId)
                }
                "comment_reply" -> {
                    putExtra("open_story_detail_from_notification", true)
                    putExtra("notification_story_id", storyId)
                }
            }
            putExtra("notification_type", notificationType)
        }
        val pending = PendingIntent.getActivity(
            this, notificationId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val appAvatar = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.app_logo)
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_stat_dramio)
            .setLargeIcon(appAvatar)
            .setCategory(NotificationCompat.CATEGORY_SOCIAL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setShowWhen(true)
            .setBadgeIconType(NotificationCompat.BADGE_ICON_LARGE)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        manager.notify(notificationId, notification)
    }
}
