# Keep metadata used by Kotlin reflection, Compose and Google/Firebase SDKs.
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*

# The Firebase messaging service is declared in AndroidManifest.xml.
-keep class com.qisaswahikayat.app.DramioFirebaseMessagingService { *; }

# Keep model constructors/fields used by Android JSON and SDK reflection.
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}

# Do not keep the whole application: allow R8 to shrink, optimize and obfuscate it.
