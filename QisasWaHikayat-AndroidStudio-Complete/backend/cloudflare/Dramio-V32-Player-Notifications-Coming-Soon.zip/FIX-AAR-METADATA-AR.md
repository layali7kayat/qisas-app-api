# إصلاح خطأ AAR Metadata في Dramio

تم تعديل `app/build.gradle.kts`:

- `compileSdk = 36` بدلاً من `35` لأن `androidx.browser:browser:1.9.0` يتطلب compileSdk 36 أو أحدث.
- أبقينا `targetSdk = 35` كما هو لتجنب تغيير سلوك التطبيق وقت التشغيل ضمن هذا الإصلاح.
- أبقينا `minSdk = 24` ومعرّف الحزمة `ap4221554.cyq` كما هما.

## الخطوات
1. افتح المشروع في Android Studio.
2. تأكد من تثبيت Android SDK Platform 36 من SDK Manager.
3. اضغط Sync Project with Gradle Files.
4. نفّذ Build > Make Project.

هذا الإصلاح يعالج رسالة AAR Metadata المحددة. إذا ظهر خطأ آخر بعده، أرسل نصه كاملاً.
