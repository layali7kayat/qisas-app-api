# تعطيل إعلانات AdMob مؤقتاً — Dramio

- Debug: `ADS_PRODUCTION_ENABLED=false` ولا تتم تهيئة Mobile Ads SDK.
- Release: `ADS_PRODUCTION_ENABLED=false` ولا تتم تهيئة Mobile Ads SDK.
- لا يتم تحميل Banner أو Native أو Interstitial أو Rewarded ولا إرسال طلبات إعلانية.
- Appodeal وجميع شركاء الوساطة ومحولات الشبكات غير موجودة في المشروع.
- تبقى معرّفات AdMob محفوظة في `DramioAdMob` و`ADMOB-IDS-AR.txt`.
- إعلان Rewarded غير متاح ولا يرسل طلبًا؛ يبقى نظام XP دون مكافأة إعلانية حتى إضافة تكامل منفصل معتمد لاحقًا.

## إعادة التفعيل لاحقًا

بعد انتهاء تعليق AdMob والتأكد من عودة الحساب إلى حالة نشطة، غيّر فقط قيمة `ADS_PRODUCTION_ENABLED` في `app/build.gradle.kts` داخل `buildTypes.release` إلى `true`. اترك Debug على `false`، ولا تختبر بالنقر على الإعلانات الحقيقية.
