-- Dramio audience insights: anonymous visitor sessions and per-user activity history.
-- The Worker also creates these tables defensively, so this migration is safe to run once.
CREATE TABLE IF NOT EXISTS audience_sessions (
  visitor_id TEXT PRIMARY KEY,
  session_started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total_seconds INTEGER NOT NULL DEFAULT 0,
  app_opens INTEGER NOT NULL DEFAULT 0,
  last_story_id INTEGER NOT NULL DEFAULT 0,
  last_episode_id TEXT NOT NULL DEFAULT '',
  last_event TEXT NOT NULL DEFAULT 'app_open'
);
CREATE TABLE IF NOT EXISTS audience_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  visitor_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  story_id INTEGER NOT NULL DEFAULT 0,
  episode_id TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audience_events_visitor_time
  ON audience_events(visitor_id, created_at);
CREATE INDEX IF NOT EXISTS idx_audience_events_type_time
  ON audience_events(event_type, created_at);

-- Import previously collected per-story events so existing listening history remains visible.
INSERT INTO audience_events(visitor_id, event_type, story_id, episode_id, created_at)
SELECT e.visitor_id, e.event_type, e.story_id, e.episode_id, e.created_at
FROM story_analytics_events e
WHERE e.visitor_id <> ''
  AND NOT EXISTS (
    SELECT 1 FROM audience_events a
    WHERE a.visitor_id = e.visitor_id
      AND a.event_type = e.event_type
      AND a.story_id = e.story_id
      AND a.episode_id = e.episode_id
      AND a.created_at = e.created_at
  );
