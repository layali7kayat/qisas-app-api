package com.qisaswahikayat.app

import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.app.Activity
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.credentials.CredentialManager
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import androidx.compose.runtime.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import com.google.firebase.messaging.FirebaseMessaging
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.FullScreenContentCallback

private object DramioAds {
    // Rewarded ads remain unavailable; no rewarded ad request is made while ads are disabled.
    fun showRewarded(activity: Activity, visitorId: String, onReward: () -> Unit, onUnavailable: () -> Unit) {
        onUnavailable()
    }
}

private object DramioAdMob {
    const val BANNER_AD_UNIT_ID = "ca-app-pub-8926612269781002/8133025827"
    const val NATIVE_AD_UNIT_ID = "ca-app-pub-8926612269781002/6968117968"
    const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-8926612269781002/9594281306"

    // Both variants are intentionally OFF until the AdMob account suspension is lifted.
    val adsEnabled: Boolean
        get() = BuildConfig.ADS_PRODUCTION_ENABLED && !BuildConfig.DEBUG

    private var initialized = false
    private var interstitialAd: InterstitialAd? = null

    fun initialize(activity: Activity) {
        if (!adsEnabled) {
            android.util.Log.d("DramioAdMob", "AdMob requests disabled by ADS_PRODUCTION_ENABLED")
            return
        }
        if (initialized) return
        initialized = true
        MobileAds.initialize(activity) {
            loadInterstitial(activity.applicationContext)
        }
    }

    private fun loadInterstitial(context: android.content.Context) {
        if (!adsEnabled) return
        InterstitialAd.load(
            context,
            INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitialAd = ad }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    android.util.Log.w("DramioAdMob", "Interstitial failed to load: ${error.message}")
                }
            }
        )
    }

    /**
     * Shows a preloaded interstitial only when one is ready. The continuation is
     * always called after dismissal/failure, or immediately when no ad is ready.
     * Returns true only when an ad was actually handed to the SDK for display.
     */
    fun showInterstitial(activity: Activity, onFinished: () -> Unit): Boolean {
        if (!adsEnabled || activity.isFinishing || activity.isDestroyed) {
            onFinished()
            return false
        }
        val ad = interstitialAd
        if (ad == null) {
            onFinished()
            return false
        }
        interstitialAd = null
        var finished = false
        fun finishAndReload() {
            if (finished) return
            finished = true
            loadInterstitial(activity.applicationContext)
            onFinished()
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() = finishAndReload()
            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                android.util.Log.w("DramioAdMob", "Interstitial failed to show: ${error.message}")
                finishAndReload()
            }
        }
        return try {
            ad.show(activity)
            true
        } catch (error: Exception) {
            android.util.Log.w("DramioAdMob", "Interstitial show exception: ${error.message}")
            finishAndReload()
            false
        }
    }
}

private fun formatNotificationTime(raw: String): String {
    val value = raw.trim()
    if (value.isBlank()) return ""
    val patterns = listOf(
        "yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX",
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'",
        "yyyy-MM-dd HH:mm:ss", "yyyy/MM/dd  HH:mm", "yyyy/MM/dd HH:mm"
    )
    for (pattern in patterns) {
        val parsed = runCatching {
            java.text.SimpleDateFormat(pattern, java.util.Locale.US).apply {
                if (pattern.endsWith("'Z'")) timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.parse(value)
        }.getOrNull()
        if (parsed != null) return java.text.SimpleDateFormat("MMM dd, yyyy  hh:mm a", java.util.Locale.US).format(parsed)
    }
    return value
}

const val API_BASE = "https://qisas-app-api.layali-7kayat-719.workers.dev" // Cloudflare Worker المستقل المعتمد
private const val GOOGLE_WEB_CLIENT_ID = "329604815492-em2u177fg9u5k7jmje1kojvgbfb8b1ff.apps.googleusercontent.com"
val Ink = Color(0xFF08090D)
val Panel = Color(0xFF15171D)
val Gold = Color(0xFFFFC400)
val Muted = Color(0xFF9A9BA5)
val Line = Color(0xFF292B34)
val TopBar = Color(0xFF090A0F)

private fun mediaUrl(path: String?): String? {
    val value = path?.trim()?.takeIf { it.isNotEmpty() && it != "null" } ?: return null
    return if (value.startsWith("https://") || value.startsWith("http://")) value
    else "$API_BASE/media/${value.trimStart('/')}"
}

private suspend fun requestJson(path: String, method: String = "GET", body: JSONObject? = null, headers: Map<String, String> = emptyMap()): JSONObject = withContext(Dispatchers.IO) {
    val connection = URL(API_BASE + path).openConnection() as HttpURLConnection
    connection.connectTimeout = 12000
    connection.readTimeout = 20000
    connection.requestMethod = method
    headers.forEach { (key, value) -> connection.setRequestProperty(key, value) }
    if (body != null) {
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
    }
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        val result = JSONObject(text)
        if (code !in 200..299) throw IllegalStateException(result.optString("error", "تعذر تنفيذ الطلب"))
        result
    } finally { connection.disconnect() }
}

private suspend fun uploadProfileAvatar(context: android.content.Context, uri: android.net.Uri, visitorId: String): String = withContext(Dispatchers.IO) {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: throw IllegalStateException("تعذر قراءة الصورة المختارة")
    if (bytes.size > 5 * 1024 * 1024) throw IllegalStateException("حجم الصورة يجب ألا يتجاوز 5 ميغابايت")
    val mime = context.contentResolver.getType(uri)?.takeIf { it in listOf("image/jpeg", "image/png", "image/webp") } ?: "image/jpeg"
    val connection = (URL("$API_BASE/api/profile/avatar?visitor_id=$visitorId").openConnection() as HttpURLConnection)
    connection.connectTimeout = 15000
    connection.readTimeout = 30000
    connection.requestMethod = "POST"
    connection.doOutput = true
    connection.setRequestProperty("Content-Type", mime)
    connection.outputStream.use { it.write(bytes) }
    val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
    val body = stream.bufferedReader().use { it.readText() }
    if (connection.responseCode !in 200..299) throw IllegalStateException(runCatching { JSONObject(body).optString("error") }.getOrDefault("تعذر رفع الصورة"))
    val key = JSONObject(body).optString("key")
    if (key.isBlank()) throw IllegalStateException("لم يرجع الخادم رابط الصورة")
    "$API_BASE/media/$key"
}

suspend fun adminRequest(path: String, idToken: String, method: String = "GET", body: String? = null): JSONObject =
    requestJson(path, method, body?.let { JSONObject(it) }, mapOf("Authorization" to "Bearer $idToken"))

private fun JSONArray.toObjects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
private fun JSONArray.toStrings(): List<String> = (0 until length()).map { optString(it) }

data class Category(val id: String, val title: String, val image: String?, val slug: String = "")
data class Story(
    val id: String, val title: String, val description: String, val audio: String,
    val image: String?, val status: String, val views: Int, val categoryIds: List<String>,
    val suggestedImage: String? = null,
    val wideImage: String? = null,
    val totalEpisodes: Int = 1,
    val createdAt: String = "",
    val characterOneName: String = "البطلة", val characterTwoName: String = "البطل", val characterThreeName: String = "شخصية محورية",
    val characterOneImage: String? = null, val characterTwoImage: String? = null, val characterThreeImage: String? = null,
    val isShortStory: Boolean = false, val isComingSoon: Boolean = false
)
data class Episode(val id: String, val title: String, val audio: String, val image: String?, val number: Int, val createdAt: String = "")
private fun isNewWithinWeek(value: String): Boolean = try {
    val normalized = value.trim().replace(" ", "T").removeSuffix("Z").substringBefore(".")
    val parser = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
    parser.timeZone = java.util.TimeZone.getTimeZone("UTC")
    val created = parser.parse(normalized)
    if (created == null) false else {
        val ageMillis = System.currentTimeMillis() - created.time
        ageMillis in 0..(7L * 24L * 60L * 60L * 1000L)
    }
} catch (_: Exception) { false }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep Android system icons (clock/date/navigation controls) light and unchanged,
        // while matching the system-bar backgrounds to Dramio's dark palette.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK)
        )
        // Keep the Android status/navigation bars visible (not immersive) and black.
        // The app continues to apply WindowInsets.systemBars so content stays clear of them.
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        // With edge-to-edge enabled, Android draws the system bars transparently.
        // The window background is what remains visible in the status/navigation inset areas.
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        DramioAdMob.initialize(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Panel)) { QisasApp() } }
    }
}




@Composable
private fun LeaderboardTierBadge(rank: Int) {
    val (label, symbol, tint, background) = when (rank) {
        in 1..5 -> Quadruple("النخبة", "👑", Color(0xFFFFD54F), Color(0xFF493817))
        in 6..10 -> Quadruple("المتميزون", "🥈", Color(0xFFE0E5EF), Color(0xFF303744))
        in 11..20 -> Quadruple("المتقدمون", "🥉", Color(0xFFD99A62), Color(0xFF493326))
        in 21..30 -> Quadruple("الطموحون", "✦", Color(0xFFC7A1FF), Color(0xFF38284F))
        else -> Quadruple("مشارك", "★", Color(0xFFB5BAC5), Color(0xFF292D36))
    }
    Row(
        modifier = Modifier.padding(top = 5.dp).clip(RoundedCornerShape(50))
            .background(background).border(1.dp, tint.copy(alpha = 0.45f), RoundedCornerShape(50))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(symbol, fontSize = 11.sp)
        Text(label, color = tint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
private fun AccountMenuRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, danger: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
        .background(Color(0xFF17130E)).border(1.dp, if (danger) Color(0xFF8F2929) else Color(0xFF57401A), RoundedCornerShape(18.dp))
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text(title, color = if (danger) Color(0xFFFF646B) else Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(14.dp))
        Icon(icon, contentDescription = null, tint = if (danger) Color(0xFFFF646B) else Gold, modifier = Modifier.size(30.dp))
        Spacer(Modifier.width(12.dp))
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
    }
}

@Composable
private fun AccountScreen(
    displayName: String?, email: String?, photoUrl: String?, customName: String?, customPhoto: String?,
    signingIn: Boolean, authError: String?,
    onSignIn: () -> Unit, onSignOut: () -> Unit,
    onSaveProfile: (String, String?) -> Unit,
    onOpenFavorites: () -> Unit, onOpenHistory: () -> Unit,
    isAdmin: Boolean = false, onOpenAdmin: () -> Unit = {}, onOpenSettings: () -> Unit = {}, onOpenAbout: () -> Unit = {}
) {
    val context = LocalContext.current
    var editableName by remember(customName) { mutableStateOf(customName.orEmpty()) }
    var selectedPhoto by remember(customPhoto) { mutableStateOf(customPhoto?.takeIf { it.isNotBlank() }) }
    var showNameEditor by remember { mutableStateOf(false) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            selectedPhoto = uri.toString()
            onSaveProfile(editableName.ifBlank { "مستخدم Dramio" }, selectedPhoto)
        }
    }
    val signedIn = !email.isNullOrBlank()

    Column(Modifier.fillMaxSize().background(Ink).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.weight(1f))
            Text("حسابي", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.weight(1f))
        }

        if (!signedIn) {
            Spacer(Modifier.height(34.dp))
            Image(
                painter = androidx.compose.ui.res.painterResource(id = R.drawable.app_logo),
                contentDescription = "Dramio",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(174.dp)
            )
            Spacer(Modifier.height(22.dp))
            Text("مرحباً بك في Dramio", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("سجّل الدخول لحفظ قصصك ومتابعة استماعك", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
            Button(
                onClick = onSignIn,
                enabled = !signingIn,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
            ) {
                if (signingIn) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Ink)
                else Text("تسجيل الدخول باستخدام Google", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            authError?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(12.dp)) }
        } else {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF17130E))
                    .border(1.dp, Color(0xFF70501A), RoundedCornerShape(24.dp)).padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("مرحباً بك", color = Muted, fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                        Text(editableName.ifBlank { "مستخدم Dramio" }, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        IconButton(onClick = { showNameEditor = true }, modifier = Modifier.size(34.dp)) {
                            Text("✎", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("عضو في Dramio", color = Gold, fontSize = 12.sp)
                }
                Spacer(Modifier.width(14.dp))
                Box(contentAlignment = Alignment.BottomEnd) {
                    if (!selectedPhoto.isNullOrBlank()) {
                        AsyncImage(model = selectedPhoto, contentDescription = "الصورة الشخصية", contentScale = ContentScale.Crop,
                            modifier = Modifier.size(92.dp).clip(RoundedCornerShape(50)).border(2.dp, Gold, RoundedCornerShape(50)))
                    } else {
                        Box(Modifier.size(92.dp).clip(RoundedCornerShape(50)).background(Color(0xFF3A2A12)).border(2.dp, Gold, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                            Text(editableName.firstOrNull()?.uppercase() ?: "D", color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    IconButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.size(32.dp).clip(RoundedCornerShape(50)).background(Gold)) {
                        Text("✎", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            AccountMenuRow("سجل المشاهدة", "القصص التي استمعت إليها مؤخراً", Icons.Default.History, onOpenHistory)
            AccountMenuRow("المفضلة", "القصص التي حفظتها للعودة إليها", Icons.Default.Favorite, onOpenFavorites)
            AccountMenuRow("الإعدادات", "تخصيص تجربتك في Dramio", Icons.Default.Settings, onOpenSettings)
            if (isAdmin) AccountMenuRow("لوحة الإدارة", "إدارة القصص والحلقات", Icons.Default.AdminPanelSettings, onOpenAdmin)
            Spacer(Modifier.height(8.dp))
            AccountMenuRow("تسجيل الخروج", "الخروج من حسابك على هذا الجهاز", Icons.Default.Logout, onSignOut, danger = true)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showNameEditor) {
        AlertDialog(
            onDismissRequest = { showNameEditor = false },
            title = { Text("تعديل الاسم", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = editableName,
                    onValueChange = { editableName = it.take(40) },
                    singleLine = true,
                    label = { Text("اسم المستخدم") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, focusedLabelColor = Gold, cursorColor = Gold)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (editableName.isNotBlank()) onSaveProfile(editableName.trim(), selectedPhoto)
                    showNameEditor = false
                }) { Text("حفظ", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { showNameEditor = false }) { Text("إلغاء", color = Muted) } },
            containerColor = Panel
        )
    }
}

@Composable
private fun AdMobBannerSlot() {
    if (!DramioAdMob.adsEnabled) return
    val context = LocalContext.current
    val adView = remember(context) {
        AdView(context).apply {
            adUnitId = DramioAdMob.BANNER_AD_UNIT_ID
            setAdSize(AdSize.BANNER)
            loadAd(AdRequest.Builder().build())
        }
    }
    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }
    AndroidView(
        modifier = Modifier.fillMaxWidth().wrapContentHeight(),
        factory = { adView }
    )
}

@Composable
private fun NativeAdCard() {
    if (!DramioAdMob.adsEnabled) return
    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    LaunchedEffect(context) {
        val loader = AdLoader.Builder(context, DramioAdMob.NATIVE_AD_UNIT_ID)
            .forNativeAd { loadedAd -> nativeAd = loadedAd }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    android.util.Log.w("DramioAdMob", "Native ad failed to load: ${error.message}")
                }
            })
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()
        loader.loadAd(AdRequest.Builder().build())
    }

    DisposableEffect(nativeAd) {
        onDispose { nativeAd?.destroy() }
    }

    nativeAd?.let { ad ->
        AndroidView(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(12.dp)).border(1.dp, Line, RoundedCornerShape(12.dp)),
            factory = { viewContext -> createDramioNativeAdView(viewContext, ad) },
            update = { it.setNativeAd(ad) }
        )
    }
}

private fun createDramioNativeAdView(context: android.content.Context, ad: NativeAd): NativeAdView {
    val adView = NativeAdView(context)
    val content = android.widget.LinearLayout(context).apply {
        orientation = android.widget.LinearLayout.VERTICAL
        setPadding(18, 14, 18, 14)
        setBackgroundColor(android.graphics.Color.rgb(23, 24, 32))
    }
    val adLabel = android.widget.TextView(context).apply {
        text = "إعلان"
        textSize = 10f
        setTextColor(android.graphics.Color.LTGRAY)
    }
    val headline = android.widget.TextView(context).apply {
        text = ad.headline
        textSize = 15f
        setTextColor(android.graphics.Color.WHITE)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    val body = android.widget.TextView(context).apply {
        text = ad.body.orEmpty()
        textSize = 12f
        setTextColor(android.graphics.Color.LTGRAY)
        setPadding(0, 6, 0, 8)
    }
    val callToAction = android.widget.Button(context).apply {
        text = ad.callToAction.orEmpty()
        isAllCaps = false
    }
    content.addView(adLabel, android.widget.LinearLayout.LayoutParams(-1, -2))
    content.addView(headline, android.widget.LinearLayout.LayoutParams(-1, -2))
    if (!ad.body.isNullOrBlank()) content.addView(body, android.widget.LinearLayout.LayoutParams(-1, -2))
    if (!ad.callToAction.isNullOrBlank()) content.addView(callToAction, android.widget.LinearLayout.LayoutParams(-2, -2))
    adView.addView(content, android.widget.FrameLayout.LayoutParams(-1, -2))
    adView.headlineView = headline
    adView.bodyView = body
    adView.callToActionView = callToAction
    adView.setNativeAd(ad)
    return adView
}

@Composable
private fun DrawerMenuRow(label: String, onClick: () -> Unit, textColor: Color = Color.White, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().height(58.dp).clickable { onClick() }.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = textColor, fontSize = 17.sp, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QisasApp() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("qisas_native", 0) }
    var googleAuthBusy by remember { mutableStateOf(false) }
    var accountAuthRefresh by remember { mutableIntStateOf(0) }
    var googleAuthMessage by remember { mutableStateOf<String?>(null) }
    var visitorId by remember {
        mutableStateOf(prefs.getString("visitor_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("visitor_id", it).apply()
        })
    }
    fun registerPushTokenIfAllowed() {
        val allowed = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (allowed) FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            scope.launch {
                runCatching {
                    val registration = JSONObject().put("visitor_id", visitorId).put("fcm_token", token)
                    val previousToken = prefs.getString("dramio_previous_fcm_token", null)
                    if (!previousToken.isNullOrBlank() && previousToken != token) {
                        registration.put("previous_fcm_token", previousToken)
                    }
                    requestJson("/api/notifications/register", "POST", registration)
                    prefs.edit().putString("dramio_fcm_token", token).remove("dramio_previous_fcm_token").apply()
                }.onFailure { android.util.Log.e("DramioFCM", "Device token registration failed", it) }
            }
        }
    }
    LaunchedEffect(visitorId) { registerPushTokenIfAllowed() }
    var notificationMessage by remember { mutableStateOf<String?>(null) }
    var unreadNotifications by remember { mutableIntStateOf(prefs.getInt("dramio_unread_notifications", 0)) }
    var notificationRevision by remember { mutableIntStateOf(0) }
    var notificationCommentId by remember { mutableStateOf<String?>(null) }
    var appInForeground by remember { mutableStateOf(true) }
    val player = remember { ExoPlayer.Builder(context).build() }
    var interstitialShowing by remember { mutableStateOf(false) }
    var lastInterstitialAt by remember { mutableLongStateOf(prefs.getLong("dramio_last_interstitial_at", 0L)) }
    // Count each episode once, on the first explicit tap of its Play button.
    // Repeated pause/resume taps do not inflate the count.
    var startedEpisodeIds by remember { mutableStateOf(setOf<String>()) }
    var meaningfulActionsSinceInterstitial by remember { mutableIntStateOf(0) }

    // Interstitials are considered only at natural content transitions, never
    // when the user opens the player or presses Play/Pause. Keep at least two
    // meaningful actions between impressions and a 5-minute global cooldown.
    fun showInterstitialThen(after: () -> Unit) {
        meaningfulActionsSinceInterstitial += 1
        val now = System.currentTimeMillis()
        val activity = context as? Activity
        val eligible = meaningfulActionsSinceInterstitial >= 2 &&
            activity != null && !interstitialShowing &&
            now - lastInterstitialAt >= 300_000L
        if (!eligible || activity == null) {
            after()
            return
        }
        interstitialShowing = true
        val shown = DramioAdMob.showInterstitial(activity) {
            interstitialShowing = false
            after()
        }
        if (shown) {
            meaningfulActionsSinceInterstitial = 0
            lastInterstitialAt = now
            prefs.edit().putLong("dramio_last_interstitial_at", now).apply()
        } else {
            interstitialShowing = false
        }
    }

    // Episode changes are natural breaks. Pause the previous audio before an
    // interstitial; selecting the next episode never starts audio automatically.
    fun showEpisodeInterstitialThen(after: () -> Unit) {
        player.pause()
        showInterstitialThen(after)
    }
    LaunchedEffect(Unit) {
        while (true) {
            unreadNotifications = prefs.getInt("dramio_unread_notifications", 0)
            kotlinx.coroutines.delay(2500)
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var categories by remember { mutableStateOf(emptyList<Category>()) }
    var stories by remember { mutableStateOf(emptyList<Story>()) }
    var latestUpdates by remember { mutableStateOf(emptyList<JSONObject>()) }
    var homeTab by remember { mutableStateOf("updates") }
    var homeListMode by remember { mutableStateOf(false) }
    var featuredStoryId by remember { mutableStateOf<String?>(null) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", true)) }
    var actorVoteStats by remember { mutableStateOf<Map<String, Pair<Int, Int>>>(emptyMap()) } // likes, dislikes
    var engagementXp by remember { mutableIntStateOf(prefs.getInt("dramio_xp", 0)) }
    var leaderboard by remember { mutableStateOf(emptyList<JSONObject>()) }
    var leaderboardLoading by remember { mutableStateOf(false) }
    var onlineCount by remember { mutableIntStateOf(0) }
    var actorMyVotes by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var actorVotesLoading by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var episodes by remember { mutableStateOf(emptyList<Episode>()) }
    var comments by remember { mutableStateOf(emptyList<JSONObject>()) }
    var loading by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var page by remember { mutableStateOf("home") }
    var storyDetailTab by remember { mutableStateOf("details") }
    // Keep the detail screen as the parent when opening a category or character list from a story.
    var categoryReturnPage by remember { mutableStateOf("home") }
    var actorReturnPage by remember { mutableStateOf("home") }
    // Home-section navigation never interrupts the user with an interstitial.
    fun navigateHomeTab(tab: String, after: () -> Unit = {}) {
        val isTabSwitch = page == "home" && homeTab != tab
        val navigate = {
            page = "home"
            homeTab = tab
            after()
        }
        if (isTabSwitch) showInterstitialThen(navigate) else navigate()
    }
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<Category?>(null) }
    var selectedStory by remember { mutableStateOf<Story?>(null) }
    var playingTitle by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    DisposableEffect(lifecycleOwner, player) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                appInForeground = true
                unreadNotifications = prefs.getInt("dramio_unread_notifications", 0)
                registerPushTokenIfAllowed()
            }
            if (event == Lifecycle.Event.ON_STOP) {
                appInForeground = false
                player.pause()
                playing = false
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    var currentEpisodeIndex by remember { mutableIntStateOf(-1) }
    var playbackPosition by remember { mutableLongStateOf(0L) }
    var playbackDuration by remember { mutableLongStateOf(0L) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }
    var commentName by remember { mutableStateOf(prefs.getString("profile_display_name", "") ?: "") }
    var commentText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var replyParentId by remember { mutableStateOf<String?>(null) }
    var editingCommentId by remember { mutableStateOf<String?>(null) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var history by remember { mutableStateOf(prefs.getStringSet("history", emptySet())?.toSet() ?: emptySet()) }
    var adminPanel by remember { mutableStateOf(false) }
    var previousPage by remember { mutableStateOf("home") }
    var selectedList by remember { mutableStateOf("أرغب بالاستماع إليها") }
    var storyLists by remember {
        mutableStateOf(runCatching {
            val saved = JSONObject(prefs.getString("story_lists", "{}") ?: "{}")
            saved.keys().asSequence().associateWith { key -> saved.optString(key).let { value -> if (value == "تمت مشاهدتها") "تم الاستماع إليها" else value } }
        }.getOrDefault(emptyMap()))
    }

    fun saveIds(key: String, ids: Set<String>) { prefs.edit().putStringSet(key, ids).apply() }
    fun rememberStory(story: Story) {
        history = (listOf(story.id) + history.filterNot { it == story.id }).take(100).toSet()
        saveIds("history", history)
    }
    fun awardEngagement(event: String, eventKey: String) {
        scope.launch {
            runCatching {
                val displayName = prefs.getString("profile_display_name", null)?.takeIf { it.isNotBlank() }
                    ?: prefs.getString("google_display_name", null)?.takeIf { it.isNotBlank() }
                    ?: prefs.getString("dramio_guest_name", null)?.takeIf { it.isNotBlank() }
                    ?: ("زائر " + UUID.randomUUID().toString().takeLast(4)).also {
                        prefs.edit().putString("dramio_guest_name", it).apply()
                    }
                val avatar = prefs.getString("profile_photo_uri", "") ?: ""
                requestJson("/api/xp/award", "POST", JSONObject()
                    .put("visitor_id", visitorId)
                    .put("display_name", displayName)
                    .put("avatar_key", avatar.substringAfter("$API_BASE/media/", "").takeIf { it.startsWith("images/avatars/") } ?: "")
                    .put("event", event).put("event_key", eventKey))
            }.onSuccess { result ->
                engagementXp = result.optInt("xp", engagementXp)
                prefs.edit().putInt("dramio_xp", engagementXp).apply()
            }
        }
    }
    fun loadLeaderboard() {
        scope.launch {
            leaderboardLoading = true
            runCatching { requestJson("/api/xp/leaderboard?visitor_id=$visitorId") }
                .onSuccess { result ->
                    engagementXp = result.optInt("my_xp", engagementXp)
                    prefs.edit().putInt("dramio_xp", engagementXp).apply()
                    leaderboard = result.optJSONArray("users")?.toObjects() ?: emptyList()
                }
            leaderboardLoading = false
        }
    }

    fun loadCatalog() {
        scope.launch {
            loading = true; error = null
            try {
                val json = requestJson("/api/catalog")
                categories = json.optJSONArray("categories")?.toObjects()?.map {
                    Category(it.optString("id"), it.optString("title"), it.optString("image_path").takeIf { v -> v.isNotBlank() && v != "null" }, it.optString("slug"))
                } ?: emptyList()
                stories = json.optJSONArray("stories")?.toObjects()?.map {
                    Story(it.optString("id"), it.optString("title"), it.optString("description"), it.optString("audio_path"),
                        it.optString("image_path").takeIf { v -> v.isNotBlank() && v != "null" }, it.optString("status", "ongoing"),
                        it.optInt("views"), it.optJSONArray("category_ids")?.toStrings() ?: emptyList(),
                        it.optString("suggested_image_path").takeIf { v -> v.isNotBlank() && v != "null" },
                        it.optString("wide_image_path").takeIf { v -> v.isNotBlank() && v != "null" }, it.optInt("total_episodes", 1),
                        it.optString("created_at"), it.optString("character_one_name", "البطلة"), it.optString("character_two_name", "البطل"), it.optString("character_three_name", "شخصية محورية"),
                        it.optString("character_one_image_path").takeIf { v -> v.isNotBlank() && v != "null" },
                        it.optString("character_two_image_path").takeIf { v -> v.isNotBlank() && v != "null" },
                        it.optString("character_three_image_path").takeIf { v -> v.isNotBlank() && v != "null" },
                        categories.any { category -> category.slug == "short-stories" && category.id in (it.optJSONArray("category_ids")?.toStrings() ?: emptyList()) },
                        categories.any { category -> category.slug == "coming-soon" && category.id in (it.optJSONArray("category_ids")?.toStrings() ?: emptyList()) })
                } ?: emptyList()
                latestUpdates = requestJson("/api/latest-updates").optJSONArray("updates")?.toObjects() ?: emptyList()
                if (featuredStoryId == null && stories.isNotEmpty()) featuredStoryId = stories.random().id
            } catch (e: Exception) { error = e.localizedMessage ?: "تعذر الاتصال بالخادم" }
            loading = false
        }
    }
    fun logStoryAnalytics(storyId: String, event: String, episodeId: String = "") {
        scope.launch { runCatching { requestJson("/api/analytics/event", "POST", JSONObject().put("story_id", storyId.toIntOrNull() ?: 0).put("visitor_id", visitorId).put("event_type", event).put("episode_id", episodeId)) } }
    }
    fun logStoryPlaybackProgress(storyId: String, episodeId: String, positionMs: Long, durationMs: Long, listenedSeconds: Int = 15) {
        if (storyId.toIntOrNull() == null || episodeId.isBlank() || durationMs <= 0L) return
        scope.launch {
            runCatching {
                requestJson("/api/analytics/event", "POST", JSONObject()
                    .put("story_id", storyId.toInt())
                    .put("visitor_id", visitorId)
                    .put("event_type", "episode_progress")
                    .put("episode_id", episodeId)
                    .put("position_ms", positionMs.coerceAtLeast(0L))
                    .put("duration_ms", durationMs.coerceAtLeast(1L))
                    .put("listened_seconds", listenedSeconds.coerceIn(1, 15)))
            }
        }
    }
    fun openStory(story: Story, targetTab: String = "details") {
        if (targetTab != "comments") notificationCommentId = null
        val openNow = {
            previousPage = page
            selectedStory = story; page = "detail"; storyDetailTab = targetTab; rememberStory(story); episodes = emptyList(); comments = emptyList(); message = null
            scope.launch {
                try {
                    val parts = requestJson("/api/story/${story.id}/parts").optJSONArray("parts")?.toObjects() ?: emptyList()
                    val visibleParts = if (story.isShortStory) emptyList() else parts
                    episodes = (if (story.audio.isNotBlank() && story.audio != "null") listOf(Episode("main-${story.id}", "الحلقة الأولى", story.audio, story.image, 1, story.createdAt)) else emptyList()) + visibleParts.map {
                        Episode(it.optString("id"), it.optString("title"), it.optString("audio_path"), it.optString("image_path").takeIf { v -> v.isNotBlank() && v != "null" }, it.optInt("sort_order") + 1, it.optString("published_at"))
                    }
                } catch (_: Exception) { episodes = if (story.audio.isNotBlank() && story.audio != "null") listOf(Episode("main-${story.id}", "الحلقة الأولى", story.audio, story.image, 1, story.createdAt)) else emptyList() }
                try {
                    comments = requestJson("/api/story/${story.id}/comments", headers = mapOf("X-Visitor-ID" to visitorId)).optJSONArray("comments")?.toObjects() ?: emptyList()
                } catch (_: Exception) { /* comments are optional if the service is unavailable */ }
            }
            scope.launch { runCatching { requestJson("/api/view/${story.id}", "POST") } }
            logStoryAnalytics(story.id, "story_open")
            Unit
        }
        // Moving from one story to another is a natural content boundary.
        showInterstitialThen(openNow)
    }
    fun playEpisode(episode: Episode) {
        val url = mediaUrl(episode.audio) ?: return
        fun prepareAndStart() {
            currentEpisodeIndex = episodes.indexOfFirst { it.id == episode.id }.let { if (it >= 0) it else 0 }
            player.setMediaItem(MediaItem.fromUri(url)); player.setPlaybackSpeed(playbackSpeed); player.prepare()
            val savedPosition = prefs.getLong("progress_${selectedStory?.id}_${episode.id}", 0L)
            if (savedPosition > 0L) player.seekTo(savedPosition)
            playingTitle = "${selectedStory?.title.orEmpty()} — ${episode.title}"
            page = "player"
            // Never autoplay: a user must explicitly press the Play triangle.
            player.pause()
            playing = false
        }
        prepareAndStart()
    }
    fun playAdjacent(direction: Int) {
        val next = currentEpisodeIndex + direction
        if (next in episodes.indices) {
            val target = episodes[next]
            if (direction > 0) {
                selectedStory?.let { logStoryAnalytics(it.id, "episode_next", target.id) }
                showEpisodeInterstitialThen { playEpisode(target) }
            } else playEpisode(target)
        }
    }
    LaunchedEffect(player, playing, currentEpisodeIndex) {
        var analyticsSeconds = 0
        while (playing) {
            playbackPosition = player.currentPosition.coerceAtLeast(0L)
            playbackDuration = player.duration.takeIf { it > 0L } ?: 0L
            if (currentEpisodeIndex in episodes.indices && playbackPosition > 0L) {
                prefs.edit().putLong("progress_${selectedStory?.id}_${episodes[currentEpisodeIndex].id}", playbackPosition).apply()
            }
            if (player.isPlaying) analyticsSeconds += 1
            if (analyticsSeconds >= 15 && currentEpisodeIndex in episodes.indices) {
                val current = episodes[currentEpisodeIndex]
                selectedStory?.let { story ->
                    logStoryPlaybackProgress(story.id, current.id, playbackPosition, playbackDuration, 15)
                }
                analyticsSeconds = 0
            }
            kotlinx.coroutines.delay(1000)
        }
    }
    DisposableEffect(player, episodes, currentEpisodeIndex) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_ENDED && currentEpisodeIndex in episodes.indices) {
                    playing = false
                    val episodeId = episodes[currentEpisodeIndex].id
                    selectedStory?.let { awardEngagement("episode_complete", "episode:${it.id}:$episodeId"); logStoryAnalytics(it.id, "episode_complete", episodeId) }
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    fun back() {
        when {
            adminPanel -> adminPanel = false
            page == "player" -> {
                player.pause(); player.stop(); playing = false; playingTitle = ""
                playbackPosition = 0L; playbackDuration = 0L; currentEpisodeIndex = -1
                page = "detail"
            }
            page == "detail" -> { page = previousPage; selectedStory = null }
            page == "category" -> { page = categoryReturnPage; selectedCategory = null }
            page == "latest-all" -> { page = "home"; homeTab = "updates" }
            page == "categories-all" -> { page = "home"; homeTab = "categories" }
            page == "actors" -> page = actorReturnPage
            page == "account" || page == "search" || page == "history" || page == "favorites" || page == "lists" || page == "notifications" -> page = previousPage
            page == "privacy" || page == "terms" || page == "cookies" || page == "disclaimer" -> page = "settings"
            else -> page = "home"
        }
    }

    DisposableEffect(page) {
        val activity = context as? Activity
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        if (page == "player") {
            controller?.let {
                it.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                it.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            }
        } else {
            controller?.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            if (player.isPlaying) {
                player.pause()
                player.stop()
                playing = false
                playingTitle = ""
            }
        }
        onDispose {
            controller?.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    BackHandler(enabled = adminPanel || page != "home" || drawerState.isOpen) { if (drawerState.isOpen) scope.launch { drawerState.close() } else back() }
    ModalNavigationDrawer(
        modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(300.dp).fillMaxHeight(),
                drawerContainerColor = if (darkMode) Color(0xFF101116) else Color(0xFFF7F7F7)
            ) {
                Column(Modifier.fillMaxHeight().verticalScroll(rememberScrollState())) {
                var drawerListsExpanded by remember { mutableStateOf(true) }
                fun closeDrawer() { scope.launch { drawerState.close() } }
                fun openList(label: String) {
                    selectedList = label
                    page = if (label == "المفضلة") "favorites" else "lists"
                    closeDrawer()
                }
                val drawerSignedIn = !prefs.getString("google_email", null).isNullOrBlank()
                val drawerName = prefs.getString("profile_display_name", null)?.takeIf { it.isNotBlank() }
                    ?: prefs.getString("google_display_name", null)?.takeIf { it.isNotBlank() }
                    ?: "مستخدم Dramio"
                val drawerPhoto = prefs.getString("profile_photo_uri", null)?.takeIf { it.isNotBlank() }
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 18.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFFFFC400))
                        .border(1.dp, Color(0xFFFFD84D), RoundedCornerShape(22.dp))
                        .clickable { closeDrawer(); showInterstitialThen { previousPage = page; page = "account" } }
                        .padding(horizontal = 16.dp, vertical = 17.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (drawerSignedIn) {
                        if (drawerPhoto != null) {
                            AsyncImage(model = drawerPhoto, contentDescription = "الصورة الشخصية",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(62.dp).clip(CircleShape).border(2.dp, Color.White, CircleShape))
                        } else {
                            Box(Modifier.size(62.dp).clip(CircleShape).background(Color(0xFF30240A)),
                                contentAlignment = Alignment.Center) {
                                Text(drawerName.firstOrNull()?.uppercase() ?: "D", color = Color.White,
                                    fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(drawerName, color = Color(0xFF17130E), fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    } else {
                        Text("تسجيل الدخول باستخدام Google", color = Color(0xFF17130E),
                            fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    }
                }
                Divider(color = Line)
                DrawerMenuRow("الرئيسية", { closeDrawer(); navigateHomeTab("updates") })
                DrawerMenuRow("البحث عن قصة", { closeDrawer(); showInterstitialThen { page = "search" } })
                DrawerMenuRow("التصنيفات", { closeDrawer(); navigateHomeTab("categories") })
                DrawerMenuRow("قائمتي", { drawerListsExpanded = !drawerListsExpanded }) {
                    Icon(if (drawerListsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = "فتح قائمتي", tint = Gold)
                }
                if (drawerListsExpanded) {
                    listOf("المفضلة", "أرغب بالاستماع إليها", "أستمع إليها حالياً", "تم الاستماع إليها", "أكمل الاستماع لاحقاً").forEach { label ->
                        Row(Modifier.fillMaxWidth().height(46.dp).clickable { openList(label) }.padding(start = 30.dp, end = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("•  $label", color = if (darkMode) Color(0xFFCFD9E1) else Color.DarkGray, fontSize = 15.sp)
                        }
                    }
                }
                DrawerMenuRow("سجل الاستماع", { closeDrawer(); showInterstitialThen { page = "history" } })
                Divider(color = Line, modifier = Modifier.padding(vertical = 8.dp))
                DrawerMenuRow("الإعدادات", { closeDrawer(); showInterstitialThen { page = "settings" } })
                Divider(color = Line, modifier = Modifier.padding(vertical = 8.dp))
                Text("© جميع الحقوق محفوظة — Dramio", color = if (darkMode) Muted else Color.DarkGray, fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp))
                }
            }
        }
    ) {
    Column(Modifier.fillMaxSize().background(if (darkMode) Ink else Color(0xFFF8F8F8)).windowInsetsPadding(WindowInsets.systemBars)) {
    Column(Modifier.weight(1f).fillMaxWidth()) {
    LaunchedEffect(visitorId, appInForeground) {
        while (appInForeground) {
            runCatching {
                val presence = requestJson("/api/online", "POST", JSONObject().put("visitor_id", visitorId))
                onlineCount = presence.optInt("online", onlineCount)
            }
            kotlinx.coroutines.delay(60_000)
        }
    }

    LaunchedEffect(visitorId) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            (context as? Activity)?.let {
                ActivityCompat.requestPermissions(it, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7342)
            }
        }
    }

    LaunchedEffect(page, homeTab, stories.size, visitorId) {
        if (page == "home" && homeTab == "engaged") loadLeaderboard()
        if ((page == "actors" || page == "detail" || (page == "home" && homeTab == "updates")) && stories.isNotEmpty()) {
            actorVotesLoading = true
            runCatching { requestJson("/api/character-votes?visitor_id=$visitorId") }
                .onSuccess { response ->
                    val stats = mutableMapOf<String, Pair<Int, Int>>()
                    val mine = mutableMapOf<String, Int>()
                    response.optJSONArray("votes")?.toObjects()?.forEach { row ->
                        val key = "${row.optString("story_id")}::${row.optString("character_key")}"
                        stats[key] = row.optInt("likes") to row.optInt("dislikes")
                        mine[key] = row.optInt("my_vote")
                    }
                    actorVoteStats = stats
                    actorMyVotes = mine
                }
            actorVotesLoading = false
        }
    }

        if (!adminPanel && page == "home") {
            Row(Modifier.fillMaxWidth().height(62.dp).background(TopBar).border(width = 0.5.dp, color = Line).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "القائمة الجانبية", tint = Gold) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Dramio", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp)
                    Text("حكايات تُروى بالصوت", color = Muted, fontSize = 10.sp)
                }
                Box {
                    IconButton(onClick = {
                    showInterstitialThen { page = "notifications"; unreadNotifications = 0; prefs.edit().putInt("dramio_unread_notifications", 0).apply() }
                    scope.launch {
                        runCatching {
                            val feed = requestJson("/api/notifications/feed?visitor_id=$visitorId").optJSONArray("notifications") ?: JSONArray()
                            val local = JSONArray()
                            for (i in 0 until feed.length()) {
                                val n = feed.optJSONObject(i) ?: continue
                                local.put(JSONObject().put("id", n.optInt("id")).put("source", n.optString("source"))
                                    .put("type", n.optString("type")).put("story_id", n.optString("story_id"))
                                    .put("comment_id", n.optString("comment_id")).put("title", n.optString("title")).put("body", n.optString("body"))
                                    .put("time", n.optString("created_at")).put("sender", n.optString("sender_name", "Dramio")).put("avatar", n.optString("sender_avatar", "app")))
                            }
                            prefs.edit().putString("dramio_notifications", local.toString()).apply()
                            notificationRevision++
                        }
                    }
                }) { Icon(Icons.Default.Notifications, "الإشعارات", tint = Color.White) }
                    if (unreadNotifications > 0) Box(Modifier.align(Alignment.TopEnd).padding(top = 3.dp, end = 3.dp).size(17.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFFE53935)), contentAlignment = Alignment.Center) {
                        Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString(), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                IconButton(onClick = { showInterstitialThen { page = "search" } }) { Icon(Icons.Default.Search, "بحث", tint = Color.White) }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).background(TopBar).padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("الرئيسية", "التصنيفات", "الأكثر استماعاً", "الجديد", "المكتملة", "الممثلون والشخصيات", "الأكثر تفاعلاً").forEachIndexed { index, label ->
                    val key = listOf("updates", "categories", "popular", "new", "completed", "actors", "engaged")[index]
                    val selected = homeTab == key
                    Column(Modifier.clickable { if (key == "actors") showInterstitialThen { actorReturnPage = "home"; page = "actors" } else navigateHomeTab(key) }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label, color = if (selected) Gold else Color.White, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                        Spacer(Modifier.height(5.dp))
                        Box(Modifier.width(22.dp).height(2.dp).clip(RoundedCornerShape(2.dp)).background(if (selected) Gold else Color.Transparent))
                    }
                }
            }
        } else if (page != "detail" && page != "player") {
            Row(Modifier.fillMaxWidth().background(TopBar).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { back() }) { Icon(Icons.Default.ArrowBack, null, tint = Gold) }
                Text(if (adminPanel) "الإدارة" else if (page == "settings") "الإعدادات" else if (page == "category") selectedCategory?.title ?: "التصنيف" else "Dramio", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
            }
        }
        if (adminPanel) {
            AdminPanelScreen(idToken = prefs.getString("google_id_token", "") ?: "", adminEmail = prefs.getString("google_email", "") ?: "", onClose = { adminPanel = false }, onCatalogChanged = { loadCatalog() })
        } else {
            if (page in setOf("actors", "category", "favorites", "history", "lists")) NativeAdCard()
            when (page) {
            "player" -> {
                val story = selectedStory
                val episode = episodes.getOrNull(currentEpisodeIndex)
                if (story != null && episode != null) EpisodePlayerScreen(
                    story = story,
                    episode = episode,
                    episodes = episodes,
                    recommendations = remember(story.id, stories) { stories.filter { it.id != story.id }.shuffled().take(6) },
                    position = playbackPosition,
                    duration = playbackDuration,
                    playing = playing,
                    speed = playbackSpeed,
                    onBack = { back() },
                    onSeek = { playbackPosition = it; player.seekTo(it) },
                    onToggle = {
                        if (player.isPlaying) { player.pause(); playing = false }
                        else {
                            val episodeId = episodes.getOrNull(currentEpisodeIndex)?.id.orEmpty()
                            selectedStory?.let { logStoryAnalytics(it.id, "episode_play", episodeId) }
                            if (episodeId.isNotBlank() && episodeId !in startedEpisodeIds) {
                                startedEpisodeIds = startedEpisodeIds + episodeId
                                meaningfulActionsSinceInterstitial += 1
                            }
                            player.play()
                            playing = true
                        }
                    },
                    onPrevious = { playAdjacent(-1) },
                    onNext = { playAdjacent(1) },
                    onSpeed = { playbackSpeed = if (playbackSpeed >= 2f) 0.75f else playbackSpeed + 0.25f; player.setPlaybackSpeed(playbackSpeed) },
                    onSelectEpisode = { selected ->
                        if (selected.id != episodes.getOrNull(currentEpisodeIndex)?.id) showEpisodeInterstitialThen { playEpisode(selected) }
                    },
                    onOpenStory = { nextStory ->
                        player.pause(); player.stop(); playing = false; playingTitle = ""
                        openStory(nextStory)
                    }
                )
            }
            "detail" -> {
                val story = selectedStory
                if (story != null) StoryDetailScreen(story, categories, episodes, comments, commentName,
                    prefs.getString("profile_photo_uri", null)?.takeIf { it.isNotBlank() },
                    { commentName = it; prefs.edit().putString("display_name", it).apply() }, commentText, { commentText = it }, message,
                    notificationsEnabled = prefs.getBoolean("story_notifications_${story.id}", false), notificationMessage = notificationMessage,
                    onToggleNotifications = { enable ->
                        if (enable && Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(context as Activity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7341)
                            notificationMessage = "اسمح بالإشعارات من نافذة الهاتف، ثم اضغط الجرس مرة أخرى لتفعيل التنبيهات"
                        } else {
                            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                                if (!task.isSuccessful || task.result.isNullOrBlank()) {
                                    notificationMessage = "تعذر تهيئة الإشعارات. تأكد من إضافة google-services.json وربط Firebase بالمشروع."
                                } else {
                                    scope.launch {
                                        try {
                                            requestJson("/api/notifications/register", "POST", JSONObject().put("visitor_id", visitorId).put("fcm_token", task.result))
                                            requestJson("/api/notifications/subscribe", "POST", JSONObject()
                                                .put("visitor_id", visitorId).put("story_id", story.id).put("fcm_token", task.result).put("enabled", enable))
                                            prefs.edit().putBoolean("story_notifications_${story.id}", enable).apply()
                                            notificationMessage = if (enable) "تم تفعيل إشعارات هذه القصة" else "تم إلغاء متابعة إشعارات هذه القصة"
                                        } catch (e: Exception) { notificationMessage = e.localizedMessage ?: "تعذر حفظ إعداد الإشعارات" }
                                    }
                                }
                            }
                        }
                    },
                    onPlay = { playEpisode(it) }, onSendComment = {
                        if (commentText.isBlank()) message = "اكتبي تعليقك أولًا" else scope.launch {
                            busy = true
                            try {
                                val payload = JSONObject().put("visitor_id", visitorId)
                                    .put("display_name", prefs.getString("profile_display_name", null)?.takeIf { it.isNotBlank() } ?: commentName.ifBlank { "زائر" })
                                    .put("content", commentText)
                                    .put("avatar", prefs.getString("profile_photo_uri", null)?.takeIf { it.isNotBlank() } ?: "dramio-default")
                                if (editingCommentId != null) {
                                    requestJson("/api/comment/$editingCommentId", "PUT", JSONObject().put("visitor_id", visitorId).put("content", commentText))
                                } else {
                                    replyParentId?.let { payload.put("parent_id", it) }
                                    requestJson("/api/story/${story.id}/comments", "POST", payload)
                                }
                                if (editingCommentId == null) {
                                    val dayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                                    awardEngagement("comment", "comment:$dayKey")
                                }
                                commentText = ""; replyParentId = null; editingCommentId = null
                                comments = requestJson("/api/story/${story.id}/comments", headers = mapOf("X-Visitor-ID" to visitorId)).optJSONArray("comments")?.toObjects() ?: emptyList()
                                message = "تم نشر تعليقك"
                            } catch (e: Exception) { message = e.localizedMessage ?: "تعذر نشر التعليق" }
                            busy = false
                        }
                    }, onLikeComment = { comment ->
                        scope.launch {
                            try {
                                requestJson("/api/comment/${comment.optString("id")}/like", "POST", JSONObject().put("visitor_id", visitorId))
                                comments = requestJson("/api/story/${story.id}/comments", headers = mapOf("X-Visitor-ID" to visitorId)).optJSONArray("comments")?.toObjects() ?: emptyList()
                            } catch (e: Exception) { message = e.localizedMessage ?: "تعذر تسجيل الإعجاب" }
                        }
                    }, onReplyComment = { comment -> editingCommentId = null; replyParentId = comment.optString("id"); message = "الرد على: ${comment.optString("display_name", "زائر")}" },
                    onEditComment = { comment -> editingCommentId = comment.optString("id"); replyParentId = null; commentText = comment.optString("content"); message = "تعديل تعليقك ثم اضغطي نشر" },
                    onDeleteComment = { comment -> scope.launch { try { requestJson("/api/comment/${comment.optString("id")}", "DELETE", JSONObject().put("visitor_id", visitorId)); comments = requestJson("/api/story/${story.id}/comments", headers = mapOf("X-Visitor-ID" to visitorId)).optJSONArray("comments")?.toObjects() ?: emptyList(); message = "تم حذف التعليق" } catch (e: Exception) { message = e.localizedMessage ?: "تعذر حذف التعليق" } } },
                    isFavorite = story.id in favorites, onFavorite = {
                        val addingFavorite = story.id !in favorites
                        logStoryAnalytics(story.id, if (addingFavorite) "favorite_add" else "favorite_remove")
                        favorites = if (story.id in favorites) favorites - story.id else favorites + story.id
                        saveIds("favorites", favorites)
                    }, currentList = storyLists[story.id].orEmpty(), onSetList = { label ->
                        val updated = storyLists.toMutableMap()
                        if (label.isBlank()) updated.remove(story.id) else updated[story.id] = label
                        storyLists = updated.toMap()
                        prefs.edit().putString("story_lists", JSONObject().apply { updated.forEach { (id, value) -> put(id, value) } }.toString()).apply()
                    }, playingTitle = playingTitle, playing = playing, onTogglePlay = { if (player.isPlaying) { player.pause(); playing = false } else { selectedStory?.let { logStoryAnalytics(it.id, "episode_play", episodes.getOrNull(currentEpisodeIndex)?.id.orEmpty()) }; player.play(); playing = true } },
                    onBack = { back() },
                    actorVoteStats = actorVoteStats,
                    actorMyVotes = actorMyVotes,
                    onCharacterLike = { characterKey ->
                        scope.launch {
                            val voteKey = "${story.id}::$characterKey"
                            val currentVote = actorMyVotes[voteKey] ?: 0
                            runCatching {
                                requestJson("/api/character-vote", "POST", JSONObject()
                                    .put("story_id", story.id.toIntOrNull() ?: 0)
                                    .put("character_key", characterKey)
                                    .put("visitor_id", visitorId)
                                    .put("vote", if (currentVote == 1) 0 else 1))
                            }.onSuccess { result ->
                                val key = "${result.optString("story_id")}::${result.optString("character_key")}"
                                actorVoteStats = actorVoteStats + (key to (result.optInt("likes") to result.optInt("dislikes")))
                                actorMyVotes = actorMyVotes + (key to result.optInt("my_vote"))
                            }.onFailure { message = it.localizedMessage ?: "تعذر تسجيل الإعجاب" }
                        }
                    },
                    onOpenActors = { showInterstitialThen { actorReturnPage = page; page = "actors" } },
                    onOpenCategory = { category -> showInterstitialThen { categoryReturnPage = page; selectedCategory = category; page = "category" } },
                    onSelectedTabChange = { storyDetailTab = it },
                    initialTab = storyDetailTab,
                    focusCommentId = notificationCommentId)
            }
            "category" -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { page = categoryReturnPage; selectedCategory = null }) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Gold) }
                    Text(selectedCategory?.title ?: "التصنيف", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                val filtered = stories.filter { selectedCategory != null && selectedCategory!!.id in it.categoryIds }
                StoryList(filtered, onOpen = { openStory(it) })
            }
            "latest-all" -> {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { page = "home"; homeTab = "updates" }) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Gold) }
                    Text("أحدث المسلسلات", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                StoryList(stories.sortedByDescending { it.createdAt }, onOpen = { openStory(it) })
            }
            "categories-all" -> Column {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { page = "home"; homeTab = "categories" }) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Gold) }
                    Text("التصنيفات", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    categories.forEachIndexed { categoryIndex, category ->
                        item(key = "category-all-${category.id}") { CategoryCard(category) { showInterstitialThen { categoryReturnPage = page; selectedCategory = category; page = "category" } } }
                        if ((categoryIndex + 1) % 4 == 0 && categoryIndex < categories.lastIndex) {
                            item(key = "category-all-native-ad-$categoryIndex", span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) { NativeAdCard() }
                        }
                    }
                }
            }
            "actors" -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("الممثلون والشخصيات", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                val actorRows = stories.flatMap { story -> listOf(
                    Triple("character_one", story.characterOneName, story.characterOneImage) to story,
                    Triple("character_two", story.characterTwoName, story.characterTwoImage) to story,
                    Triple("character_three", story.characterThreeName, story.characterThreeImage) to story
                ) }.filter { it.first.second.isNotBlank() && !it.first.third.isNullOrBlank() }
                    .distinctBy { it.first.first + "::" + it.second.id }
                if (actorVotesLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold)
                val rankedActorRows = actorRows.sortedByDescending { row ->
                    val key = "${row.second.id}::${row.first.first}"
                    actorVoteStats[key]?.first ?: 0
                }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    rankedActorRows.forEachIndexed { actorIndex, actorRow ->
                        val actor = actorRow.first
                        val actorStory = actorRow.second
                        item(key = "actor-${actor.first}-${actorStory.id}") {
                        val characterKey = actor.first
                        val actorName = actor.second
                        val actorImage = actor.third
                        val voteKey = "${actorStory.id}::$characterKey"
                        val stats = actorVoteStats[voteKey] ?: (0 to 0)
                        val myVote = actorMyVotes[voteKey] ?: 0
                        Card(colors = CardDefaults.cardColors(containerColor = if (darkMode) Panel else Color.White), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(model = mediaUrl(actorImage), contentDescription = actorName, contentScale = ContentScale.Crop, modifier = Modifier.size(76.dp).clip(RoundedCornerShape(12.dp)).clickable { openStory(actorStory) })
                                Column(Modifier.weight(1f).padding(horizontal = 10.dp).clickable { openStory(actorStory) }) {
                                    Text(actorName, color = if (darkMode) Color.White else Color.Black, fontWeight = FontWeight.Bold, maxLines = 2)
                                    Text(actorStory.title, color = Muted, fontSize = 12.sp, maxLines = 2)
                                    Text("افتح القصة", color = Gold, fontSize = 12.sp)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(onClick = {
                                        scope.launch {
                                            runCatching { requestJson("/api/character-vote", "POST", JSONObject().put("story_id", actorStory.id.toIntOrNull() ?: 0).put("character_key", characterKey).put("visitor_id", visitorId).put("vote", if (myVote == 1) 0 else 1)) }
                                                .onSuccess { r ->
                                                    val newKey = "${r.optString("story_id")}::${r.optString("character_key")}"
                                                    actorVoteStats = actorVoteStats + (newKey to (r.optInt("likes") to r.optInt("dislikes")))
                                                    actorMyVotes = actorMyVotes + (newKey to r.optInt("my_vote"))
                                                }.onFailure { message = it.localizedMessage ?: "تعذر إرسال التصويت" }
                                        }
                                    }) { Icon(Icons.Default.ThumbUp, "إعجاب", tint = if (myVote == 1) Gold else Muted) }
                                    Text(stats.first.toString(), color = Muted, fontSize = 10.sp)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(onClick = {
                                        scope.launch {
                                            runCatching { requestJson("/api/character-vote", "POST", JSONObject().put("story_id", actorStory.id.toIntOrNull() ?: 0).put("character_key", characterKey).put("visitor_id", visitorId).put("vote", if (myVote == -1) 0 else -1)) }
                                                .onSuccess { r ->
                                                    val newKey = "${r.optString("story_id")}::${r.optString("character_key")}"
                                                    actorVoteStats = actorVoteStats + (newKey to (r.optInt("likes") to r.optInt("dislikes")))
                                                    actorMyVotes = actorMyVotes + (newKey to r.optInt("my_vote"))
                                                }.onFailure { message = it.localizedMessage ?: "تعذر إرسال التصويت" }
                                        }
                                    }) { Icon(Icons.Default.ThumbDown, "عدم إعجاب", tint = if (myVote == -1) Color.Red else Muted) }
                                    Text(stats.second.toString(), color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                        }
                        if ((actorIndex + 1) % 5 == 0 && actorIndex < rankedActorRows.lastIndex) item(key = "native-actor-ad-$actorIndex") { NativeAdCard() }
                    }
                }
            }
            "privacy" -> LegalPage("سياسة الخصوصية", "نحترم خصوصيتك. قد يحتفظ التطبيق بتفضيلاتك محلياً مثل المفضلة وسجل الاستماع، وقد يعالج بيانات ضرورية لتقديم الخدمة. لا تشارك معلومات حساسة عبر التعليقات. تواصل معنا لطلبات الخصوصية أو حذف البيانات المرتبطة بك.", darkMode)
            "terms" -> LegalPage("شروط الاستخدام", "باستخدام التطبيق، توافق على الالتزام بالقوانين واحترام حقوق الملكية الفكرية والخصوصية. يمنع نسخ المحتوى أو إعادة نشره أو استخدامه تجارياً دون موافقة مكتوبة. قد تتغير الخدمات أو تتوقف للصيانة، ويحق للإدارة إزالة المحتوى المخالف.", darkMode)
            "cookies" -> LegalPage("سياسة ملفات الارتباط", "قد يستخدم التطبيق أو موقعه ملفات تعريف الارتباط أو تقنيات مشابهة لتذكر التفضيلات وتحسين الأداء وقياس الاستخدام. يمكنك التحكم في ملفات الارتباط من إعدادات المتصفح عند استخدام الموقع. قد يؤدي تعطيلها إلى تأثر بعض الوظائف.", darkMode)
            "disclaimer" -> LegalPage("إخلاء المسؤولية", "المحتوى المنشور يهدف إلى الترفيه. نبذل جهداً للحفاظ على دقة المعلومات وتوفر الخدمة، لكن لا نضمن خلوها من الأخطاء أو الانقطاع. حقوق القصص والصور والصوتيات محفوظة لأصحابها. يرجى التواصل معنا عند وجود ادعاء حقوقي ليتم مراجعته.", darkMode)
            "notifications" -> {
                val stored = remember(notificationRevision, page) {
                    runCatching { JSONArray(prefs.getString("dramio_notifications", "[]") ?: "[]") }.getOrDefault(JSONArray())
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("الإشعارات", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        scope.launch { runCatching { requestJson("/api/notifications/dismiss", "POST", JSONObject().put("visitor_id", visitorId).put("all", true)) } }
                        prefs.edit().putString("dramio_notifications", "[]").putInt("dramio_unread_notifications", 0).apply()
                        unreadNotifications = 0
                        notificationRevision++
                    }, enabled = stored.length() > 0) { Text("مسح الكل", color = if (stored.length() > 0) Gold else Muted) }
                }
                if (stored.length() == 0) {
                    Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { Text("لا توجد إشعارات جديدة", color = Muted) }
                } else {
                    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        (0 until stored.length()).forEach { index ->
                            val notice = stored.optJSONObject(index)
                            if (notice != null) {
                                item(key = "notification-$index") {
                                    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().clickable {
                                        val storyId = notice.optString("story_id")
                                        val commentId = notice.optString("comment_id")
                                        if (storyId.isNotBlank() && storyId != "null") {
                                            stories.firstOrNull { it.id == storyId }?.let { story ->
                                                notificationCommentId = commentId.takeIf { it.isNotBlank() && it != "null" }
                                                openStory(story, if (notificationCommentId != null) "comments" else "details")
                                            }
                                        }
                                    }) {
                                        Column(Modifier.padding(14.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Image(painter = androidx.compose.ui.res.painterResource(id = R.drawable.app_logo), contentDescription = "Dramio", modifier = Modifier.size(28.dp).clip(CircleShape))
                                                Spacer(Modifier.width(7.dp))
                                                Text(notice.optString("sender", "Dramio"), color = Gold, fontWeight = FontWeight.Bold)
                                            }
                                            Text(notice.optString("title"), color = Color.White, fontWeight = FontWeight.SemiBold)
                                            Text(notice.optString("body"), color = Color.White, fontSize = 13.sp)
                                            Text(formatNotificationTime(notice.optString("time")), color = Muted, fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "search" -> {
                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), label = { Text("ابحث عن قصة") }, singleLine = true)
                StoryList(stories.filter { it.title.contains(query, true) || it.description.contains(query, true) }, onOpen = { openStory(it) })
            }
            "account" -> {
                val accountEmail = if (accountAuthRefresh >= 0) prefs.getString("google_email", null) else null
                AccountScreen(
                    displayName = prefs.getString("google_display_name", null),
                    email = accountEmail?.takeIf { it.isNotBlank() }?.let { "signed-in" },
                    photoUrl = null,
                    customName = prefs.getString("profile_display_name", null),
                    customPhoto = prefs.getString("profile_photo_uri", null),
                    signingIn = googleAuthBusy,
                    authError = googleAuthMessage,
                    onSignIn = {
                        if (!googleAuthBusy) scope.launch {
                            googleAuthBusy = true
                            googleAuthMessage = null
                            try {
                                val activity = context as? Activity
                                    ?: throw IllegalStateException("تعذر فتح نافذة Google من هذه الشاشة")
                                val googleOption = GetGoogleIdOption.Builder()
                                    .setFilterByAuthorizedAccounts(false)
                                    .setServerClientId(GOOGLE_WEB_CLIENT_ID)
                                    .setAutoSelectEnabled(false)
                                    .build()
                                val request = GetCredentialRequest.Builder()
                                    .addCredentialOption(googleOption)
                                    .build()
                                val credentialManager = CredentialManager.create(activity)
                                // First try the standard account chooser. If the device has no
                                // saved credential is unavailable or needs reauthentication, launch the explicit Google sign-in flow.
                                val result = try {
                                    credentialManager.getCredential(activity, request)
                                } catch (_: GetCredentialException) {
                                    // Recover from a stale Google Credential Manager session.
                                    // A cached account can otherwise repeatedly fail with
                                    // [16] Account reauth failed on subsequent attempts.
                                    runCatching {
                                        credentialManager.clearCredentialState(ClearCredentialStateRequest())
                                    }
                                    val signInWithGoogle = GetSignInWithGoogleOption.Builder(
                                        GOOGLE_WEB_CLIENT_ID
                                    ).build()
                                    val fallbackRequest = GetCredentialRequest.Builder()
                                        .addCredentialOption(signInWithGoogle)
                                        .build()
                                    credentialManager.getCredential(activity, fallbackRequest)
                                }
                                val credential = result.credential
                                if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                    throw IllegalStateException("لم يتم اختيار حساب Google. حاولي مرة أخرى")
                                }
                                val googleToken = GoogleIdTokenCredential.createFrom(credential.data)
                                val displayName = prefs.getString("profile_display_name", null)?.takeIf { it.isNotBlank() }
                                    ?: prefs.getString("dramio_guest_name", null)?.takeIf { it.isNotBlank() }
                                    ?: ("زائر " + UUID.randomUUID().toString().takeLast(4)).also {
                                        prefs.edit().putString("dramio_guest_name", it).apply()
                                    }
                                val response = requestJson(
                                    "/api/auth/google", "POST",
                                    JSONObject().put("id_token", googleToken.idToken)
                                        .put("display_name", displayName)
                                        .put("visitor_id", visitorId)
                                )
                                val user = response.optJSONObject("user")
                                    ?: throw IllegalStateException("لم يُكمل الخادم تسجيل الدخول")
                                val accountVisitorId = response.optString("visitor_id").takeIf {
                                    it.matches(Regex("[a-zA-Z0-9-]{20,80}"))
                                } ?: throw IllegalStateException("لم يستطع الخادم ربط نقاط XP بحسابك")
                                visitorId = accountVisitorId
                                engagementXp = response.optInt("xp", 0)
                                prefs.edit()
                                    .putString("visitor_id", accountVisitorId)
                                    .putInt("dramio_xp", engagementXp)
                                    .putString("google_display_name", user.optString("display_name", displayName))
                                    .putString("google_email", user.optString("email", googleToken.id))
                                    .putString("google_sub", user.optString("google_sub"))
                                    .putString("google_id_token", googleToken.idToken)
                                    .putString("profile_display_name", response.optJSONObject("profile")?.optString("display_name")
                                        ?.takeIf { it.isNotBlank() && it != "مستخدم Dramio" } ?: displayName)
                                    .putString("profile_photo_uri", response.optJSONObject("profile")?.optString("avatar_url")
                                        ?.takeIf { it.startsWith("http") } ?: "")
                                    .apply()
                                accountAuthRefresh++
                                message = "تم تسجيل الدخول باستخدام Google بنجاح"
                            } catch (e: Exception) {
                                googleAuthMessage = when (e) {
                                    is GoogleIdTokenParsingException -> "تعذر قراءة بيانات حساب Google"
                                    else -> e.localizedMessage ?: "تعذر تسجيل الدخول باستخدام Google"
                                }
                            } finally {
                                googleAuthBusy = false
                            }
                        }
                    },
                    onSignOut = {
                        // Clear Google's Credential Manager state as well as local app state.
                        // Otherwise a later sign-in may enter a stale AccountReauth flow and fail [16].
                        scope.launch {
                            runCatching {
                                CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
                            }
                        }
                        // Keep the persistent device visitor ID and its XP when signing out.
                        // Signing out changes the Google session, not the user's Dramio identity.
                        prefs.edit()
                            .putString("visitor_id", visitorId)
                            .putInt("dramio_xp", engagementXp)
                            .remove("google_display_name").remove("google_email")
                            .remove("google_photo").remove("google_id_token").remove("google_sub")
                            .apply()
                        accountAuthRefresh++
                        message = "تم تسجيل الخروج. ستبقى هويتك ونقاطك محفوظة على هذا الجهاز"
                    },
                    onSaveProfile = { profileName, profilePhoto ->
                        scope.launch {
                            try {
                                val savedPhoto = if (profilePhoto?.startsWith("content://") == true || profilePhoto?.startsWith("file://") == true) {
                                    uploadProfileAvatar(context, android.net.Uri.parse(profilePhoto), visitorId)
                                } else profilePhoto
                                val avatarKey = savedPhoto.orEmpty()
                                    .substringAfter("$API_BASE/media/", "")
                                    .takeIf { it.startsWith("images/avatars/") } ?: ""
                                val cleanProfileName = profileName.trim().take(40)
                                val savedProfile = requestJson("/api/profile/update", "POST", JSONObject()
                                    .put("visitor_id", visitorId)
                                    .put("display_name", cleanProfileName)
                                    .put("avatar_key", avatarKey))
                                val serverProfile = savedProfile.optJSONObject("profile")
                                    ?: throw IllegalStateException("لم يُرجع الخادم بيانات الملف الشخصي")
                                val confirmedName = serverProfile.optString("display_name", "")
                                if (!savedProfile.optBoolean("success") || confirmedName != cleanProfileName) {
                                    throw IllegalStateException("لم يؤكد الخادم حفظ الاسم الجديد")
                                }
                                prefs.edit().putString("profile_display_name", confirmedName).putString("profile_photo_uri", savedPhoto.orEmpty()).apply()
                                commentName = confirmedName
                                accountAuthRefresh++
                                loadLeaderboard()
                                message = "تم حفظ بيانات حسابك ومزامنتها للجميع"
                            } catch (e: Exception) { message = e.localizedMessage ?: "تعذر حفظ الصورة" }
                        }
                    },
                    onOpenFavorites = { showInterstitialThen { page = "favorites" } },
                    onOpenHistory = { showInterstitialThen { page = "history" } },
                    onOpenSettings = { showInterstitialThen { page = "settings" } },
                    onOpenAbout = { showInterstitialThen { page = "about" } },
                    isAdmin = prefs.getString("google_email", "")?.equals("layali.7kayat@gmail.com", ignoreCase = true) == true && !prefs.getString("google_id_token", "").isNullOrBlank(),
                    onOpenAdmin = { adminPanel = true }
                )

            }
            "settings" -> SettingsScreen(onOpenLegal = { page = it }, darkMode = darkMode)
            "about" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("حول Dramio", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Dramio — حكايات تُروى بالصوت. استمتع بالقصص والحلقات الصوتية، واحفظ مفضلاتك وتابع جديد الحلقات.", color = if (darkMode) Color.White else Color(0xFF222222), fontSize = 15.sp, lineHeight = 25.sp)
            }
            "favorites", "history" -> {
                Text(if (page == "favorites") "المفضلة" else "سجل الاستماع", color = Gold, fontSize = 20.sp, modifier = Modifier.padding(16.dp))
                val ids = if (page == "favorites") favorites else history
                StoryList(stories.filter { it.id in ids }, onOpen = { openStory(it) })
            }
            "lists" -> {
                Text("قائمتي", color = Gold, fontSize = 20.sp, modifier = Modifier.padding(16.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("أرغب بالاستماع إليها", "أستمع إليها حالياً", "تم الاستماع إليها", "أكمل الاستماع لاحقاً").forEach { label ->
                        TextButton(onClick = { selectedList = label }) { Text(label, color = if (selectedList == label) Gold else Muted, fontSize = 10.sp) }
                    }
                }
                StoryList(stories.filter { storyLists[it.id] == selectedList }, onOpen = { openStory(it) })
            }
            else -> {
                if (loading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }
                else if (error != null) Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { Text(error!!, color = Color.White); Button(onClick = { loadCatalog() }) { Text("إعادة المحاولة") } }
                else Column(Modifier.fillMaxSize()) {
                    if (homeTab == "categories") {
                        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            categories.forEachIndexed { categoryIndex, category ->
                                item(key = "category-${category.id}") { CategoryCard(category) { showInterstitialThen { categoryReturnPage = page; selectedCategory = category; page = "category" } } }
                                if ((categoryIndex + 1) % 4 == 0 && categoryIndex < categories.lastIndex) {
                                    item(key = "category-native-ad-$categoryIndex", span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) { NativeAdCard() }
                                }
                            }
                        }
                    } else {
                        val featured = stories.firstOrNull { it.id == featuredStoryId } ?: stories.firstOrNull()
                        LaunchedEffect(stories.size) { if (stories.size > 1) { while (true) { kotlinx.coroutines.delay(6500); featuredStoryId = stories.filterNot { it.id == featuredStoryId }.randomOrNull()?.id } } }
                        PullToRefreshBox(isRefreshing = loading, onRefresh = { loadCatalog() }, modifier = Modifier.fillMaxSize()) {
                        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
                            if (homeTab != "engaged") item {
                                AnimatedContent(targetState = featured, transitionSpec = {
                                    (slideInHorizontally { it } + fadeIn()).togetherWith(slideOutHorizontally { -it } + fadeOut())
                                }, label = "featured-carousel") { current ->
                                    if (current != null) FeaturedSeriesCard(current) { openStory(current) }
                                }
                            }
                            if (homeTab != "engaged") item { NativeAdCard() }
                            if (homeTab == "actors") {
                                item { SectionHeading("الممثلون والشخصيات", "الأكثر حصولاً على الإعجابات يظهر أولاً", "عرض الكل") { showInterstitialThen { page = "actors" } } }
                                item {
                                    val rankedActors = stories.flatMap { actorStory ->
                                        listOf(
                                            Triple(actorStory, "character_one", actorStory.characterOneName to actorStory.characterOneImage),
                                            Triple(actorStory, "character_two", actorStory.characterTwoName to actorStory.characterTwoImage),
                                            Triple(actorStory, "character_three", actorStory.characterThreeName to actorStory.characterThreeImage)
                                        ).filter { it.third.first.isNotBlank() }
                                    }.sortedByDescending { actor ->
                                        actorVoteStats["${actor.first.id}::${actor.second}"]?.first ?: 0
                                    }
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        rankedActors.forEach { actor ->
                                            val actorStory = actor.first
                                            val actorKey = actor.second
                                            val actorName = actor.third.first
                                            val actorImage = actor.third.second
                                            val voteKey = "${actorStory.id}::$actorKey"
                                            val vote = actorMyVotes[voteKey] ?: 0
                                            val stats = actorVoteStats[voteKey] ?: (0 to 0)
                                            Column(Modifier.width(116.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                AsyncImage(model = mediaUrl(actorImage), contentDescription = actorName, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(112.dp).clip(RoundedCornerShape(10.dp)).clickable { openStory(actorStory) })
                                                Text(actorName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.clickable { openStory(actorStory) }.padding(top = 5.dp))
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(onClick = { scope.launch { runCatching { requestJson("/api/character-vote", "POST", JSONObject().put("story_id", actorStory.id.toIntOrNull() ?: 0).put("character_key", actorKey).put("visitor_id", visitorId).put("vote", if (vote == 1) 0 else 1)) }.onSuccess { r -> val k = "${r.optString("story_id")}::${r.optString("character_key")}"; actorVoteStats = actorVoteStats + (k to (r.optInt("likes") to r.optInt("dislikes"))); actorMyVotes = actorMyVotes + (k to r.optInt("my_vote")) } } }) { Icon(Icons.Default.ThumbUp, null, tint = if (vote == 1) Gold else Muted, modifier = Modifier.size(18.dp)) }
                                                    Text(stats.first.toString(), color = Muted, fontSize = 10.sp)
                                                    IconButton(onClick = { scope.launch { runCatching { requestJson("/api/character-vote", "POST", JSONObject().put("story_id", actorStory.id.toIntOrNull() ?: 0).put("character_key", actorKey).put("visitor_id", visitorId).put("vote", if (vote == -1) 0 else -1)) }.onSuccess { r -> val k = "${r.optString("story_id")}::${r.optString("character_key")}"; actorVoteStats = actorVoteStats + (k to (r.optInt("likes") to r.optInt("dislikes"))); actorMyVotes = actorMyVotes + (k to r.optInt("my_vote")) } } }) { Icon(Icons.Default.ThumbDown, null, tint = if (vote == -1) Color.Red else Muted, modifier = Modifier.size(18.dp)) }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (homeTab == "engaged") {
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text("رصيدك من XP", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                            Text("$engagementXp XP", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                            Text("استمع للحلقات، اكتب التعليقات، وادخل يومياً لتتقدم في الترتيب.", color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
                                            val rewardActivity = LocalContext.current as? Activity
                                            Button(
                                                onClick = {
                                                    if (rewardActivity == null) {
                                                        message = "تعذر فتح الإعلان حالياً"
                                                    } else {
                                                        DramioAds.showRewarded(
                                                            rewardActivity,
                                                            visitorId = visitorId,
                                                            onReward = {
                                                                // The client callback only starts a silent refresh. XP remains
                                                                // server-authoritative; legacy AdMob SSV rewards are disabled in this build
                                                                // has credited the account in Cloudflare.
                                                                val xpBeforeAd = engagementXp
                                                                scope.launch {
                                                                    repeat(90) {
                                                                        kotlinx.coroutines.delay(2000)
                                                                        val refreshed = runCatching {
                                                                            requestJson("/api/xp/leaderboard?visitor_id=$visitorId")
                                                                        }.getOrNull()
                                                                        if (refreshed != null) {
                                                                            val confirmedXp = refreshed.optInt("my_xp", engagementXp)
                                                                            if (confirmedXp >= xpBeforeAd + 10) {
                                                                                engagementXp = confirmedXp
                                                                                prefs.edit().putInt("dramio_xp", confirmedXp).apply()
                                                                                leaderboard = refreshed.optJSONArray("users")?.toObjects() ?: leaderboard
                                                                                message = "تمت إضافة 10 XP إلى رصيدك"
                                                                                return@launch
                                                                            }
                                                                        }
                                                                    }
                                                                    // No pending/waiting message: keep the current balance and
                                                                    // let the next normal leaderboard refresh pick up late SSV.
                                                                }
                                                            },
                                                            onUnavailable = { message = "الإعلان غير متاح الآن، حاول مرة أخرى بعد قليل" }
                                                        )
                                                    }
                                                },
                                                modifier = Modifier.fillMaxWidth(),
                                                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                                                shape = RoundedCornerShape(12.dp)
                                            ) { Text("▶ شاهد إعلاناً واكسب 10 XP", fontWeight = FontWeight.Bold) }
                                            message?.let { Text(it, color = Muted, fontSize = 11.sp) }
                                        }
                                    }
                                }
                                if (leaderboardLoading) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold) }
                                leaderboard.forEachIndexed { leaderboardIndex, user ->
                                    item(key = "leaderboard-${user.optString("visitor_id")}") {
                                        val rank = user.optInt("rank")
                                        val isCurrentUser = user.optBoolean("is_me", false)
                                        val tierBackground = when (rank) {
                                            in 1..5 -> Color(0xFF3B321D)
                                            in 6..10 -> Color(0xFF252B35)
                                            in 11..20 -> Color(0xFF30251F)
                                            in 21..30 -> Color(0xFF292238)
                                            else -> Panel
                                        }
                                        val rankTint = when (rank) {
                                            in 1..5 -> Color(0xFFFFD54F)
                                            in 6..10 -> Color(0xFFE0E5EF)
                                            in 11..20 -> Color(0xFFD99A62)
                                            in 21..30 -> Color(0xFFC7A1FF)
                                            else -> Muted
                                        }
                                        Card(colors = CardDefaults.cardColors(containerColor = if (isCurrentUser) Color(0xFF3B321D) else tierBackground), modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Text("#$rank", color = rankTint, fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.width(48.dp))
                                                AsyncImage(model = mediaUrl(user.optString("avatar_key").takeIf { it.isNotBlank() }), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(24.dp)).background(Line))
                                                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                                    Text(user.optString("display_name", "مستخدم Dramio") + if (isCurrentUser) " · أنت" else "", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                                                    Text("${user.optInt("xp")} XP", color = if (isCurrentUser) Gold else Muted, fontSize = 12.sp)
                                                    LeaderboardTierBadge(rank)
                                                }
                                            }
                                        }
                                    }
                                    if ((leaderboardIndex + 1) % 5 == 0 && leaderboardIndex < leaderboard.lastIndex) item(key = "native-leaderboard-ad-$leaderboardIndex") { NativeAdCard() }
                                }
                                item { NativeAdCard() }
                            } else if (homeTab == "updates" || homeTab == "new") {
                                item { SectionHeading(if (homeTab == "new") "الجديد على Dramio" else "أحدث القصص", "اكتشف حكايات جديدة", "عرض الكل") { showInterstitialThen { page = "latest-all" } } }
                                item {
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                        stories.sortedByDescending { it.createdAt }.forEach { item -> CompactPosterCard(item) { openStory(item) } }
                                    }
                                }
                                item { SectionHeading("آخر التحديثات", "أحدث الحلقات المضافة") }
                                item {
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                        latestUpdates.distinctBy { it.optString("story_id") + "-" + it.optString("episode_number") }.take(16).forEach { update ->
                                            val target = stories.firstOrNull { it.id == update.optString("story_id") }
                                            if (target != null) Box(Modifier.width(122.dp)) { LatestUpdateCard(update, target) { openStory(target) } }
                                        }
                                    }
                                }
                                item { NativeAdCard() }
                                var actorShelfAdded = false
                                categories.forEach { category ->
                                    val categoryStories = stories.filter { category.id in it.categoryIds }
                                    if (categoryStories.isNotEmpty()) {
                                        val categorySubtitle = when (category.slug) {
                                            "coming-soon" -> "حكايات تستعد للظهور"
                                            "short-stories" -> "حكايات مكتملة في حلقة واحدة"
                                            else -> "حكايات من تصنيف ${category.title}"
                                        }
                                        item { SectionHeading(category.title, categorySubtitle, "عرض الكل") { showInterstitialThen { categoryReturnPage = page; selectedCategory = category; page = "category" } } }
                                        item {
                                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                                categoryStories.forEach { storyItem -> CompactPosterCard(storyItem) { openStory(storyItem) } }
                                            }
                                        }
                                        item { NativeAdCard() }
                                        if (category.title.contains("قصص قبل النوم")) {
                                            actorShelfAdded = true
                                            item { SectionHeading("الممثلون والشخصيات", "ادعم شخصياتك المفضلة بالإعجاب أو عدم الإعجاب", "عرض الكل") { showInterstitialThen { actorReturnPage = "home"; page = "actors" } } }
                                            item {
                                                val actorItems = stories.flatMap { actorStory ->
                                                    listOf(
                                                        Triple(actorStory, "character_one", actorStory.characterOneName to actorStory.characterOneImage),
                                                        Triple(actorStory, "character_two", actorStory.characterTwoName to actorStory.characterTwoImage),
                                                        Triple(actorStory, "character_three", actorStory.characterThreeName to actorStory.characterThreeImage)
                                                    ).filter { it.third.first.isNotBlank() && it.third.second?.isNotBlank() == true }
                                                }.sortedByDescending { actorVoteStats["${it.first.id}::${it.second}"]?.first ?: 0 }
                                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    actorItems.forEach { actor ->
                                                        val actorStory = actor.first
                                                        val actorKey = actor.second
                                                        val actorName = actor.third.first
                                                        val actorImage = actor.third.second
                                                        val voteKey = "${actorStory.id}::$actorKey"
                                                        val vote = actorMyVotes[voteKey] ?: 0
                                                        val stats = actorVoteStats[voteKey] ?: (0 to 0)
                                                        Column(Modifier.width(116.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                            AsyncImage(model = mediaUrl(actorImage), contentDescription = actorName, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(112.dp).clip(RoundedCornerShape(10.dp)).clickable { openStory(actorStory) })
                                                            Text(actorName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.clickable { openStory(actorStory) }.padding(top = 5.dp))
                                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                                IconButton(onClick = { scope.launch { runCatching { requestJson("/api/character-vote", "POST", JSONObject().put("story_id", actorStory.id.toIntOrNull() ?: 0).put("character_key", actorKey).put("visitor_id", visitorId).put("vote", if (vote == 1) 0 else 1)) }.onSuccess { r ->
                                                                    val k = "${r.optString("story_id")}::${r.optString("character_key")}"
                                                                    actorVoteStats = actorVoteStats + (k to (r.optInt("likes") to r.optInt("dislikes")))
                                                                    actorMyVotes = actorMyVotes + (k to r.optInt("my_vote"))
                                                                }.onFailure { message = it.localizedMessage ?: "تعذر تسجيل الإعجاب" } } }) { Icon(Icons.Default.ThumbUp, null, tint = if (vote == 1) Gold else Muted, modifier = Modifier.size(18.dp)) }
                                                                Text(stats.first.toString(), color = Muted, fontSize = 10.sp)
                                                                IconButton(onClick = { scope.launch { runCatching { requestJson("/api/character-vote", "POST", JSONObject().put("story_id", actorStory.id.toIntOrNull() ?: 0).put("character_key", actorKey).put("visitor_id", visitorId).put("vote", if (vote == -1) 0 else -1)) }.onSuccess { r ->
                                                                    val k = "${r.optString("story_id")}::${r.optString("character_key")}"
                                                                    actorVoteStats = actorVoteStats + (k to (r.optInt("likes") to r.optInt("dislikes")))
                                                                    actorMyVotes = actorMyVotes + (k to r.optInt("my_vote"))
                                                                }.onFailure { message = it.localizedMessage ?: "تعذر تسجيل التصويت" } } }) { Icon(Icons.Default.ThumbDown, null, tint = if (vote == -1) Color.Red else Muted, modifier = Modifier.size(18.dp)) }
                                                                Text(stats.second.toString(), color = Muted, fontSize = 10.sp)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (!actorShelfAdded) {
                                    item { SectionHeading("الممثلون والشخصيات", "ادعم شخصياتك المفضلة بالإعجاب أو عدم الإعجاب", "عرض الكل") { showInterstitialThen { actorReturnPage = "home"; page = "actors" } } }
                                    item {
                                        val actorItems = stories.flatMap { actorStory ->
                                            listOf(
                                                Triple(actorStory, "character_one", actorStory.characterOneName to actorStory.characterOneImage),
                                                Triple(actorStory, "character_two", actorStory.characterTwoName to actorStory.characterTwoImage),
                                                Triple(actorStory, "character_three", actorStory.characterThreeName to actorStory.characterThreeImage)
                                            ).filter { it.third.first.isNotBlank() && it.third.second?.isNotBlank() == true }
                                        }.sortedByDescending { actorVoteStats["${it.first.id}::${it.second}"]?.first ?: 0 }
                                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            actorItems.forEach { actor ->
                                                val actorStory = actor.first
                                                val actorKey = actor.second
                                                val actorName = actor.third.first
                                                val actorImage = actor.third.second
                                                val voteKey = "${actorStory.id}::$actorKey"
                                                val vote = actorMyVotes[voteKey] ?: 0
                                                val stats = actorVoteStats[voteKey] ?: (0 to 0)
                                                Column(Modifier.width(116.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                    AsyncImage(model = mediaUrl(actorImage), contentDescription = actorName, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(112.dp).clip(RoundedCornerShape(10.dp)).clickable { openStory(actorStory) })
                                                    Text(actorName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.clickable { openStory(actorStory) }.padding(top = 5.dp))
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        IconButton(onClick = { scope.launch { runCatching { requestJson("/api/character-vote", "POST", JSONObject().put("story_id", actorStory.id.toIntOrNull() ?: 0).put("character_key", actorKey).put("visitor_id", visitorId).put("vote", if (vote == 1) 0 else 1)) }.onSuccess { r -> val k = "${r.optString("story_id")}::${r.optString("character_key")}"; actorVoteStats = actorVoteStats + (k to (r.optInt("likes") to r.optInt("dislikes"))); actorMyVotes = actorMyVotes + (k to r.optInt("my_vote")) } } }) { Icon(Icons.Default.ThumbUp, null, tint = if (vote == 1) Gold else Muted, modifier = Modifier.size(18.dp)) }
                                                        Text(stats.first.toString(), color = Muted, fontSize = 10.sp)
                                                        IconButton(onClick = { scope.launch { runCatching { requestJson("/api/character-vote", "POST", JSONObject().put("story_id", actorStory.id.toIntOrNull() ?: 0).put("character_key", actorKey).put("visitor_id", visitorId).put("vote", if (vote == -1) 0 else -1)) }.onSuccess { r -> val k = "${r.optString("story_id")}::${r.optString("character_key")}"; actorVoteStats = actorVoteStats + (k to (r.optInt("likes") to r.optInt("dislikes"))); actorMyVotes = actorMyVotes + (k to r.optInt("my_vote")) } } }) { Icon(Icons.Default.ThumbDown, null, tint = if (vote == -1) Color.Red else Muted, modifier = Modifier.size(18.dp)) }
                                                        Text(stats.second.toString(), color = Muted, fontSize = 10.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else if (homeTab == "popular") {
                                item { SectionHeading("الأكثر استماعاً", "القصص التي يفضلها المستمعون") }
                                stories.sortedByDescending { it.views }.forEachIndexed { rankIndex, popularStory ->
                                    item(key = "popular-top-${popularStory.id}") {
                                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
                                            .clip(RoundedCornerShape(14.dp)).background(Panel)
                                            .clickable { openStory(popularStory) }.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically) {
                                            Text("TOP ${rankIndex + 1}", color = Gold, fontWeight = FontWeight.Black, fontSize = 15.sp, modifier = Modifier.width(72.dp))
                                            AsyncImage(model = mediaUrl(popularStory.image), contentDescription = popularStory.title,
                                                contentScale = ContentScale.Crop, modifier = Modifier.size(76.dp, 96.dp).clip(RoundedCornerShape(9.dp)))
                                            Column(Modifier.weight(1f).padding(horizontal = 11.dp)) {
                                                Text(popularStory.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2)
                                                Text("${popularStory.views} استماع", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
                                                Text(if (popularStory.status == "completed") "مكتملة" else "مستمرة", color = Gold, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                    if ((rankIndex + 1) % 4 == 0 && rankIndex < stories.sortedByDescending { it.views }.lastIndex) {
                                        item(key = "popular-native-ad-$rankIndex") { NativeAdCard() }
                                    }
                                }
                            } else if (homeTab == "completed") {
                                item { SectionHeading("قصص مكتملة", "استمتع بالحكاية من البداية إلى النهاية") }
                                stories.filter { it.status == "completed" }.forEachIndexed { completedIndex, storyItem ->
                                    item(key = "completed-${storyItem.id}") { StoryCard(storyItem) { openStory(storyItem) } }
                                    if ((completedIndex + 1) % 4 == 0 && completedIndex < stories.count { it.status == "completed" } - 1) {
                                        item(key = "completed-native-ad-$completedIndex") { NativeAdCard() }
                                    }
                                }
                            }
                            if (stories.isEmpty() && !loading) item { Text("لا توجد قصص منشورة حالياً", color = Muted, modifier = Modifier.padding(24.dp)) }
                        }
                        }
                    }
                }
            }
            }
        }
    } // end weighted page area
        val showBottomBanner = !adminPanel && (
            page in setOf("home", "actors", "category", "player", "favorites", "history", "lists") ||
                (page == "detail" && storyDetailTab != "comments")
            )
        if (showBottomBanner && appInForeground) AdMobBannerSlot()
    }
    }
    LaunchedEffect(Unit) {
        val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        awardEngagement("daily_login", "daily:$todayKey")
        loadCatalog()
    }
}


@Composable
private fun EpisodePlayerScreen(
    story: Story,
    episode: Episode,
    episodes: List<Episode>,
    recommendations: List<Story>,
    position: Long,
    duration: Long,
    playing: Boolean,
    speed: Float,
    onBack: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggle: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSpeed: () -> Unit,
    onSelectEpisode: (Episode) -> Unit,
    onOpenStory: (Story) -> Unit
) {
    var showAllEpisodes by remember(story.id) { mutableStateOf(false) }
    val visibleEpisodes = if (showAllEpisodes) episodes else episodes.take(4)
    val progress = if (duration > 0L) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Ink),
        contentPadding = PaddingValues(bottom = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF101116)).padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "العودة", tint = Gold)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("يُشغَّل الآن", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("DRAMIO AUDIO", color = Color.White, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Gold), contentAlignment = Alignment.Center) {
                    Text("D", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp).padding(top = 8.dp, bottom = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.fillMaxWidth(0.62f).aspectRatio(1f)
                        .clip(RoundedCornerShape(24.dp)).background(Panel)
                        .border(1.dp, Color(0xFF343640), RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = mediaUrl(episode.image ?: story.image),
                        contentDescription = story.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(54.dp).background(Color(0x9908090D)))
                    Text("DRAMIO  •  قصة صوتية", Modifier.align(Alignment.BottomCenter).padding(bottom = 17.dp), color = Color.White, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text(story.title, color = Color.White, fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2)
                Spacer(Modifier.height(5.dp))
                Text("${if (episode.number >= story.totalEpisodes.coerceAtLeast(1)) "الحلقة الأخيرة" else "الحلقة ${episode.number}"}  ·  ${episode.title}", color = Muted, fontSize = 12.sp, maxLines = 1)
                Spacer(Modifier.height(10.dp))
                Slider(
                    value = progress,
                    onValueChange = { onSeek(it.toLong()) },
                    valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Color(0xFF343640)),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatPlayerTime(position), color = Color(0xFFD7D7DC), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Text(formatPlayerTime(duration), color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.height(9.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TextButton(onClick = onSpeed) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${speed}x", color = Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("السرعة", color = Muted, fontSize = 10.sp)
                        }
                    }
                    IconButton(onClick = onPrevious, enabled = episode.number > 1, modifier = Modifier.size(52.dp)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "الحلقة السابقة", tint = if (episode.number > 1) Color.White else Muted, modifier = Modifier.size(29.dp))
                            Text("السابق", color = Muted, fontSize = 9.sp)
                        }
                    }
                    Box(
                        Modifier.size(70.dp).clip(RoundedCornerShape(24.dp)).background(Gold).clickable(onClick = onToggle),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "إيقاف مؤقت" else "تشغيل", tint = Ink, modifier = Modifier.size(43.dp))
                    }
                    IconButton(onClick = onNext, enabled = episode.number < episodes.size, modifier = Modifier.size(52.dp)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SkipNext, contentDescription = "الحلقة التالية", tint = if (episode.number < episodes.size) Color.White else Muted, modifier = Modifier.size(29.dp))
                            Text("التالي", color = Muted, fontSize = 9.sp)
                        }
                    }
                    TextButton(onClick = { showAllEpisodes = !showAllEpisodes }) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.ViewList, contentDescription = "قائمة الحلقات", tint = Gold, modifier = Modifier.size(22.dp))
                            Text("الحلقات", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        item { NativeAdCard() }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("قائمة الحلقات", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Text("تابع الاستماع من الحلقة التي تفضلها", color = Muted, fontSize = 11.sp)
                }
                Text("${episodes.size} حلقات", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        visibleEpisodes.forEachIndexed { partIndex, part ->
            item(key = "player-${part.id}") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (part.id == episode.id) Color(0xFF29230F) else Panel)
                        .border(if (part.id == episode.id) 1.dp else 0.dp, if (part.id == episode.id) Gold.copy(alpha = 0.65f) else Color.Transparent, RoundedCornerShape(16.dp))
                        .clickable { onSelectEpisode(part) }.padding(11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = mediaUrl(part.image ?: story.image), contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(58.dp).clip(RoundedCornerShape(11.dp))
                    )
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text("الحلقة ${part.number}", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(part.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        if (part.id == episode.id) Text(if (playing) "قيد التشغيل الآن" else "الحلقة الحالية", color = Muted, fontSize = 10.sp)
                    }
                    Icon(if (part.id == episode.id && playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "تشغيل الحلقة", tint = Gold, modifier = Modifier.size(27.dp))
                }
            }
            if ((partIndex + 1) % 4 == 0 && partIndex != visibleEpisodes.lastIndex) item(key = "player-native-ad-${partIndex + 1}") { NativeAdCard() }
        }
        if (episodes.size > 4) {
            item {
                TextButton(onClick = { showAllEpisodes = !showAllEpisodes }, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                    Text(if (showAllEpisodes) "عرض حلقات أقل" else "عرض جميع الحلقات (${episodes.size})", color = Gold, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (recommendations.isNotEmpty()) {
            item {
                Text("قد يعجبك أيضاً", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp))
            }
            item(key = "suggested-native-ad") { NativeAdCard() }
            items(recommendations, key = { "suggested-${it.id}" }) { suggested ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
                        .clip(RoundedCornerShape(15.dp)).background(Panel)
                        .clickable { onOpenStory(suggested) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(model = mediaUrl(suggested.image), contentDescription = suggested.title, contentScale = ContentScale.Crop, modifier = Modifier.width(68.dp).aspectRatio(3f / 4f).clip(RoundedCornerShape(10.dp)))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(suggested.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                        Text("قصة صوتية", color = Muted, fontSize = 11.sp)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Gold)
                }
            }
        }
    }
}

private fun formatPlayerTime(milliseconds: Long): String {
    val total = (milliseconds.coerceAtLeast(0L) / 1000L).toInt()
    return "%d:%02d".format(total / 60, total % 60)
}

@Composable
private fun SectionHeading(title: String, subtitle: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        if (actionLabel != null && onAction != null) TextButton(onClick = onAction) { Text(actionLabel, color = Gold, fontSize = 12.sp) }
    }
}

@Composable
private fun FeaturedSeriesCard(story: Story, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(1f).clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = mediaUrl(story.wideImage ?: story.image),
            contentDescription = story.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().aspectRatio(1f)
        )
        Box(
            Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    colorStops = arrayOf(
                        0.48f to Color.Transparent,
                        0.72f to Color(0x66000000),
                        1f to Color(0xE6000000)
                    )
                )
            )
        )
        Column(
            Modifier.align(Alignment.BottomEnd).fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text("اختيار Dramio", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(
                story.title,
                color = Color.White,
                fontSize = 16.sp,
                lineHeight = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                when {
                    story.isComingSoon -> "حكايات تستعد للظهور"
                    story.isShortStory -> "حكاية مكتملة في حلقة واحدة"
                    else -> "${story.totalEpisodes.coerceAtLeast(1)} حلقة  •  ${if (story.status == "completed") "مكتملة" else "مستمرة"}"
                },
                color = Color(0xFFE4E1DC),
                fontSize = 10.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun CompactPosterCard(story: Story, onClick: () -> Unit) {
    Column(Modifier.width(148.dp).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(12.dp)).background(Panel).border(1.dp, Line, RoundedCornerShape(12.dp))) {
            AsyncImage(model = mediaUrl(story.image), contentDescription = story.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            if (!story.isShortStory && !story.isComingSoon) {
                Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xDD08090D)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text("${story.totalEpisodes.coerceAtLeast(1)} حلقة", color = Gold, fontSize = 10.sp)
                }
            } else if (story.isComingSoon) {
                Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xDD08090D)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text("قريباً", color = Gold, fontSize = 10.sp)
                }
            }
        }
        Text(story.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 19.sp, maxLines = 2, modifier = Modifier.fillMaxWidth().padding(horizontal = 9.dp).padding(top = 8.dp))
        Text(if (story.status == "completed") "مكتمل" else "مستمر", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
    }
}

@Composable
private fun HomeTab(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.fillMaxHeight().clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
        Text(label, color = if (selected) Color(0xFFF2C94C) else Color(0xFFB9B9C0), fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(3.dp).background(if (selected) Color(0xFFF2C94C) else Color.Transparent))
    }
}

@Composable
private fun LatestUpdateCard(update: JSONObject, story: Story, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f).clip(RoundedCornerShape(10.dp)).background(Color(0xFF15243A)).border(1.dp, Color(0xFF2A3C52), RoundedCornerShape(10.dp))) {
            AsyncImage(model = mediaUrl(update.optString("image_path").takeIf { it.isNotBlank() && it != "null" } ?: story.image), contentDescription = story.title, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Text("الحلقة ${update.optInt("episode_number", 1)}", modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp).background(Color(0xE6071220), RoundedCornerShape(5.dp)).padding(horizontal = 6.dp, vertical = 3.dp), color = Color(0xFFF2F3F8), fontSize = 9.sp, maxLines = 1)
        }
        Text(story.title, modifier = Modifier.fillMaxWidth().padding(top = 7.dp), color = Color(0xFFF4F5F9), fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 17.sp, maxLines = 2)
        Text(update.optString("category_title", "غير مصنفة"), modifier = Modifier.fillMaxWidth(), color = Color(0xFF9EACC1), fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun LatestUpdateListCard(update: JSONObject, story: Story, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(2.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = mediaUrl(update.optString("image_path").takeIf { it.isNotBlank() && it != "null" } ?: story.image), contentDescription = story.title, modifier = Modifier.width(92.dp).aspectRatio(3f / 4f).background(Panel, RoundedCornerShape(9.dp)), contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(story.title, color = Color(0xFFF4F5F9), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("الحلقة ${update.optInt("episode_number", 1)}", color = Gold, fontSize = 12.sp)
            Text(update.optString("category_title", "غير مصنفة"), color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.PlayArrow, null, tint = Gold)
    }
}

@Composable
private fun CategoryCard(category: Category, onClick: () -> Unit) {
    Column(Modifier.width(148.dp).clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Line, RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(bottom = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(model = mediaUrl(category.image), contentDescription = category.title, modifier = Modifier.fillMaxWidth().aspectRatio(1.15f), contentScale = ContentScale.Crop)
        Text(category.title, color = Color(0xFFF5F1E8), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 13.dp), maxLines = 2)
    }
}

@Composable
private fun StoryCard(story: Story, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = mediaUrl(story.image), contentDescription = null, modifier = Modifier.width(88.dp).aspectRatio(3f / 4f).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(story.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(when {
                story.isComingSoon -> "حكايات تستعد للظهور"
                story.isShortStory -> "حكايات مكتملة في حلقة واحدة"
                else -> if (story.status == "completed") "مكتملة" else "مستمرة"
            }, color = Gold, fontSize = 12.sp)
            if (!story.isShortStory && !story.isComingSoon) Text("${story.totalEpisodes} حلقة  •  ${story.views} مشاهدة", color = Muted, fontSize = 11.sp)
            else Text("${story.views} مشاهدة", color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.PlayArrow, null, tint = Gold)
    }
}

@Composable
private fun StoryList(storiesToShow: List<Story>, onOpen: (Story) -> Unit) {
    if (storiesToShow.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد قصص هنا حاليًا", color = Muted) }
    else LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        storiesToShow.forEachIndexed { index, story ->
            item(key = "story-${story.id}") { StoryCard(story) { onOpen(story) } }
            if ((index + 1) % 4 == 0 && index < storiesToShow.lastIndex) {
                item(key = "native-story-ad-$index") { NativeAdCard() }
            }
        }
    }
}

private fun relativeCommentTime(raw: String): String {
    if (raw.isBlank() || raw == "null") return "الآن"
    return try {
        val instant = runCatching { java.time.Instant.parse(raw) }.getOrElse {
            val normalized = raw.replace(" ", "T").let { if (it.endsWith("Z")) it else "${it}Z" }
            java.time.Instant.parse(normalized)
        }
        val minutes = ((System.currentTimeMillis() - instant.toEpochMilli()) / 60000L).coerceAtLeast(0)
        when {
            minutes < 1 -> "الآن"
            minutes < 60 -> "منذ $minutes د"
            minutes < 1440 -> "منذ ${minutes / 60} س"
            else -> "منذ ${minutes / 1440} يوم"
        }
    } catch (_: Exception) { raw.take(16) }
}

@Composable
private fun StoryDetailScreen(
    story: Story, categories: List<Category>, episodes: List<Episode>, comments: List<JSONObject>, name: String, avatarUrl: String?, onName: (String) -> Unit,
    comment: String, onComment: (String) -> Unit, message: String?, onPlay: (Episode) -> Unit,
    onSendComment: () -> Unit, onLikeComment: (JSONObject) -> Unit, onReplyComment: (JSONObject) -> Unit,
    onEditComment: (JSONObject) -> Unit, onDeleteComment: (JSONObject) -> Unit,
    isFavorite: Boolean, onFavorite: () -> Unit, currentList: String, onSetList: (String) -> Unit,
    playingTitle: String, playing: Boolean, onTogglePlay: () -> Unit, onBack: () -> Unit,
    notificationsEnabled: Boolean, notificationMessage: String?, onToggleNotifications: (Boolean) -> Unit,
    actorVoteStats: Map<String, Pair<Int, Int>>, actorMyVotes: Map<String, Int>,
    onCharacterLike: (String) -> Unit, onOpenActors: () -> Unit, onOpenCategory: (Category) -> Unit,
    onSelectedTabChange: (String) -> Unit,
    initialTab: String = "details",
    focusCommentId: String? = null
) {
    var selectedTab by remember(story.id, initialTab) { mutableStateOf(initialTab) }
    var descriptionExpanded by remember(story.id) { mutableStateOf(false) }
    var expandedReplyThreads by remember(story.id) { mutableStateOf<Set<String>>(emptySet()) }
    val detailBg = Color(0xFF090A0F)
    val detailText = Color(0xFFF6F4F1)
    val detailMuted = Color(0xFF9A9BA5)
    val teal = Gold
    val orderedRootComments = remember(comments, focusCommentId) {
        val roots = comments.filter { it.isNull("parent_id") || it.optString("parent_id").isBlank() || it.optString("parent_id") == "null" }
            .sortedByDescending { it.optString("created_at", it.optString("createdAt")) }
        val focused = roots.firstOrNull { it.optString("id") == focusCommentId }
        if (focused != null) listOf(focused) + roots.filterNot { it.optString("id") == focusCommentId } else roots
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF08090D))) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Row(Modifier.fillMaxWidth().background(detailBg).heightIn(min = 66.dp).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = detailText) }
                Text(story.title, color = detailText, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f), maxLines = 2)
                IconButton(onClick = { onToggleNotifications(!notificationsEnabled) }) {
                    Icon(Icons.Default.Notifications, contentDescription = if (notificationsEnabled) "إلغاء إشعارات القصة" else "تفعيل إشعارات القصة", tint = if (notificationsEnabled) Gold else detailText)
                }
                Text(if (isFavorite) "♥" else "♡", color = Color(0xFFFF6B82), fontSize = 25.sp, modifier = Modifier.clickable { onFavorite() }.padding(start = 6.dp))
            }
        }
        if (notificationMessage != null) item {
            Text(notificationMessage, color = if (notificationsEnabled) Gold else detailMuted, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().background(Panel).padding(horizontal = 16.dp, vertical = 9.dp))
        }
        item {
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                AsyncImage(model = mediaUrl(story.suggestedImage ?: story.image), contentDescription = story.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, Color(0xF5000000)))))
                Column(Modifier.align(Alignment.BottomEnd).padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text(if (story.isComingSoon) "قريباً" else if (story.isShortStory) "قصة قصيرة" else "مسلسل صوتي", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(Color(0x9908090D), RoundedCornerShape(30.dp)).padding(horizontal = 11.dp, vertical = 5.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (!story.isShortStory && !story.isComingSoon) Text("${story.totalEpisodes.coerceAtLeast(1)} حلقة", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.background(Color(0x9908090D), RoundedCornerShape(30.dp)).padding(horizontal = 11.dp, vertical = 6.dp))
                        Text("${story.views} استماع", color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.background(Color(0x9908090D), RoundedCornerShape(30.dp)).padding(horizontal = 11.dp, vertical = 6.dp))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().background(detailBg).border(width = 0.5.dp, color = Line), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("details" to "التفاصيل", "episodes" to "الحلقات", "comments" to "التعليقات").forEach { (key, label) ->
                    Column(Modifier.weight(1f).clickable { selectedTab = key; onSelectedTabChange(key) }.padding(vertical = 15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label, color = if (selectedTab == key) Color.White else Color(0xFFA9BAC4), fontSize = 15.sp, fontWeight = if (selectedTab == key) FontWeight.Bold else FontWeight.Medium)
                        Spacer(Modifier.height(8.dp))
                        Box(Modifier.fillMaxWidth(0.72f).height(4.dp).background(if (selectedTab == key) Color.White else Color.Transparent, RoundedCornerShape(8.dp)))
                    }
                }
            }
        }
        item { NativeAdCard() }
        if (selectedTab == "details") {
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                        AsyncImage(model = mediaUrl(story.image), contentDescription = story.title, contentScale = ContentScale.Crop,
                            modifier = Modifier.width(112.dp).aspectRatio(3f / 4f).clip(RoundedCornerShape(10.dp)).border(1.dp, Line, RoundedCornerShape(10.dp)))
                        Column(Modifier.weight(1f).padding(top = 3.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(story.title, color = detailText, fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.ExtraBold)
                            Text(if (story.status == "completed") "مكتملة" else "مستمرة", color = Color.White, fontWeight = FontWeight.Bold,
                                modifier = Modifier.background(Gold, RoundedCornerShape(50)).padding(horizontal = 11.dp, vertical = 4.dp), fontSize = 12.sp)
                            if (!story.isShortStory && !story.isComingSoon) Text("${story.totalEpisodes.coerceAtLeast(1)} حلقة", color = detailText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            if (story.isComingSoon) Text("حكايات تستعد للظهور", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            if (story.createdAt.isNotBlank()) Text(story.createdAt.take(10), color = detailMuted, fontSize = 12.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp).heightIn(min = 82.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) { Text("★", color = Color(0xFFFFB321), fontSize = 24.sp); Text("4.8", color = detailText, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("/5", color = detailText) }
                            Text("التقييم", color = detailMuted, fontSize = 12.sp)
                        }
                        Box(Modifier.width(1.dp).height(55.dp).background(Line))
                        var listMenu by remember { mutableStateOf(false) }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            Column(Modifier.fillMaxWidth().clickable { listMenu = true }.padding(horizontal = 8.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("＋", color = detailText, fontSize = 27.sp, lineHeight = 27.sp)
                                Text("قائمتي", color = detailText, fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(currentList.ifBlank { "إضافة إلى قائمتي" }, color = detailMuted, fontSize = 11.sp, lineHeight = 16.sp, maxLines = 2)
                            }
                            DropdownMenu(expanded = listMenu, onDismissRequest = { listMenu = false }) {
                                listOf("أرغب بالاستماع إليها", "أستمع إليها حالياً", "تم الاستماع إليها", "أكمل الاستماع لاحقاً", "إزالة من قائمتي").forEach { label ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = { onSetList(if (label == "إزالة من قائمتي") "" else label); listMenu = false })
                                }
                            }
                        }
                    }
                    Column(Modifier.fillMaxWidth().background(brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF171820), Color(0xFF101116))), shape = RoundedCornerShape(14.dp)).padding(12.dp)) {
                        Text("وصف القصة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(story.description.ifBlank { "لا يوجد وصف لهذه القصة حتى الآن." }, color = Color(0xFFE7EDF1), fontSize = 12.sp, lineHeight = 18.sp, maxLines = if (descriptionExpanded) Int.MAX_VALUE else 3)
                        if (story.description.length > 120) {
                            TextButton(onClick = { descriptionExpanded = !descriptionExpanded }, contentPadding = PaddingValues(0.dp)) {
                                Text(if (descriptionExpanded) "▲ إخفاء" else "▼ عرض المزيد", color = teal, fontSize = 12.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(13.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        story.categoryIds.forEach { id ->
                            val categoryName = categories.firstOrNull { it.id == id }?.title ?: id
                            val category = categories.firstOrNull { it.id == id }
                            Text(categoryName, color = Color(0xFFE0E9EF), fontSize = 11.sp,
                                modifier = Modifier.clip(RoundedCornerShape(50))
                                    .background(Color(0xFF29232A), RoundedCornerShape(50))
                                    .clickable(enabled = category != null) { category?.let(onOpenCategory) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp))
                        }
                    }
                }
            }
            val characters = listOf(Triple(story.characterOneName, story.characterOneImage, "one"), Triple(story.characterTwoName, story.characterTwoImage, "two"), Triple(story.characterThreeName, story.characterThreeImage, "three")).filter { it.second != null }
            if (characters.isNotEmpty()) {
                item {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text("الشخصيات الرئيسية", color = detailText, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            characters.forEach { (characterName, image, keySuffix) ->
                                val characterKey = when (keySuffix) {
                                    "one" -> "character_one"
                                    "two" -> "character_two"
                                    else -> "character_three"
                                }
                                val voteKey = "${story.id}::$characterKey"
                                val stats = actorVoteStats[voteKey] ?: (0 to 0)
                                val myVote = actorMyVotes[voteKey] ?: 0
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    AsyncImage(model = mediaUrl(image), contentDescription = characterName, contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(8.dp))
                                            .border(1.dp, Color(0xFF233C4C), RoundedCornerShape(8.dp))
                                            .clickable { onOpenActors() })
                                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(characterName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                                            modifier = Modifier.weight(1f).clickable { onOpenActors() }, maxLines = 1)
                                        IconButton(onClick = { onCharacterLike(characterKey) }, modifier = Modifier.size(30.dp)) {
                                            Icon(Icons.Default.ThumbUp, contentDescription = "إعجاب بالشخصية",
                                                tint = if (myVote == 1) Gold else detailMuted, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    Text("${stats.first} إعجاب", color = detailMuted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                    }
                }
            }
        }
        if (selectedTab == "episodes") {
            if (episodes.isEmpty()) item { Text("لا توجد حلقات منشورة لهذه القصة حتى الآن.", color = detailMuted, modifier = Modifier.fillMaxWidth().padding(24.dp)) }
            episodes.forEachIndexed { index, episode ->
                item(key = "detail-episode-${episode.id}") {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).background(Color(0xFF171820), RoundedCornerShape(13.dp)).clickable { onPlay(episode) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = mediaUrl(episode.image ?: story.image), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(62.dp).aspectRatio(1f).clip(RoundedCornerShape(8.dp)).border(1.dp, Line, RoundedCornerShape(8.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(if (episode.number >= story.totalEpisodes.coerceAtLeast(1)) "الحلقة الأخيرة" else "الحلقة ${episode.number}", color = teal, fontSize = 12.sp)
                            if (isNewWithinWeek(episode.createdAt)) {
                                EpisodeNewBadge()
                            }
                        }
                        Text(episode.title, color = detailText, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { onPlay(episode) }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل الحلقة", tint = teal, modifier = Modifier.size(30.dp))
                    }
                }
                }
                if ((index + 1) % 4 == 0 && index < episodes.lastIndex) {
                    item(key = "native-detail-episode-ad-$index") { NativeAdCard() }
                }
            }
        }
        if (selectedTab == "comments") {
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("التعليقات (${comments.size})", color = detailText, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("شارك رأيك مع مجتمع Dramio", color = detailMuted, fontSize = 12.sp)
                    if (comments.isEmpty()) Text("كن أول من يضيف تعليقاً", color = detailMuted)
                    message?.let { Text(it, color = Gold, fontSize = 12.sp) }
                }
            }
            orderedRootComments.forEachIndexed { commentIndex, cm ->
                item(key = "comment-${cm.optString("id")}") {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(18.dp)).background(Color(0xFF171820))
                    .border(if (cm.optString("id") == focusCommentId) 1.5.dp else 1.dp, if (cm.optString("id") == focusCommentId) Gold else Color(0xFF34313A), RoundedCornerShape(18.dp)).padding(13.dp),
                    verticalAlignment = Alignment.Top) {
                    val avatar = cm.optString("avatar").takeIf { it.startsWith("http://") || it.startsWith("https://") || it.startsWith("content://") || it.startsWith("file://") }
                    if (avatar != null) AsyncImage(model = avatar, contentDescription = "الصورة الشخصية", contentScale = ContentScale.Crop,
                        modifier = Modifier.size(46.dp).clip(RoundedCornerShape(23.dp)).border(1.dp, Gold, RoundedCornerShape(23.dp)))
                    else Box(Modifier.size(46.dp).clip(RoundedCornerShape(23.dp)).background(Color(0xFF34313A)), contentAlignment = Alignment.Center) {
                        Text(cm.optString("display_name", "ز").take(1), color = Gold, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(cm.optString("display_name", "زائر"), color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Text(relativeCommentTime(cm.optString("created_at", cm.optString("createdAt"))), color = detailMuted, fontSize = 10.sp)
                        }
                        Spacer(Modifier.height(7.dp))
                        Text(cm.optString("content"), color = detailText, lineHeight = 22.sp, fontSize = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { onLikeComment(cm) }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("♥ ${cm.optInt("likes_count")}  ${if (cm.optBoolean("liked_by_me")) "أعجبني" else "إعجاب"}", color = Gold, fontSize = 11.sp) }
                            TextButton(onClick = { onReplyComment(cm) }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("رد", color = Gold, fontSize = 11.sp) }
                            if (cm.optBoolean("is_mine")) TextButton(onClick = { onDeleteComment(cm) }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("حذف", color = Color(0xFFFF9B9B), fontSize = 11.sp) }
                        }
                        val threadId = cm.optString("id")
                        val replies = comments.filter { it.optString("parent_id") == threadId }
                        if (replies.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    expandedReplyThreads = if (threadId in expandedReplyThreads) expandedReplyThreads - threadId else expandedReplyThreads + threadId
                                },
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    if (threadId in expandedReplyThreads) "إخفاء الردود" else "عرض الردود (${replies.size})",
                                    color = Gold, fontSize = 11.sp
                                )
                            }
                            if (threadId in expandedReplyThreads) {
                                replies.forEach { reply ->
                                    Row(Modifier.fillMaxWidth().padding(top = 5.dp).background(Color(0xFF101116), RoundedCornerShape(10.dp)).padding(9.dp), verticalAlignment = Alignment.Top) {
                                        val replyAvatar = reply.optString("avatar").takeIf { it.startsWith("http://") || it.startsWith("https://") || it.startsWith("content://") || it.startsWith("file://") }
                                        if (replyAvatar != null) {
                                            AsyncImage(model = replyAvatar, contentDescription = "الصورة الشخصية", contentScale = ContentScale.Crop,
                                                modifier = Modifier.size(30.dp).clip(RoundedCornerShape(15.dp)).border(1.dp, Gold.copy(alpha = 0.65f), RoundedCornerShape(15.dp)))
                                        } else {
                                            Box(Modifier.size(30.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFF34313A)), contentAlignment = Alignment.Center) {
                                                Text(reply.optString("display_name", "ز").take(1), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(reply.optString("display_name", "زائر"), color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(reply.optString("content"), color = detailText, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                }
            }
        }
    }
    if (selectedTab == "comments") {
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xFF111218))
            .border(1.dp, Color(0xFF35313A)).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = comment, onValueChange = onComment, modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب تعليقك...", color = detailMuted, fontSize = 13.sp) }, maxLines = 2,
                shape = RoundedCornerShape(24.dp), colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF49434B), focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Gold))
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onSendComment, enabled = comment.isNotBlank()) {
                Icon(Icons.Default.Send, contentDescription = "إرسال التعليق", tint = if (comment.isNotBlank()) Gold else detailMuted)
            }
        }
    }
    }
}


@Composable
private fun EpisodeNewBadge() {
    val transition = rememberInfiniteTransition(label = "newEpisodeBlink")
    val opacity by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650),
            repeatMode = RepeatMode.Reverse
        ),
        label = "newEpisodeOpacity"
    )
    Text(
        text = "جديد",
        color = Color(0xFFFF5C8A),
        fontSize = 9.sp,
        fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.alpha(opacity)
    )
}

@Composable
private fun SettingsScreen(onOpenLegal: (String) -> Unit, darkMode: Boolean) {
    val context = LocalContext.current
    val textColor = if (darkMode) Color(0xFFE2E8ED) else Color(0xFF222222)
    val cardColor = if (darkMode) Color(0xFF1A2B35) else Color(0xFFFFFFFF)
    LazyColumn(Modifier.fillMaxSize().background(if (darkMode) Ink else Color(0xFFF8F8F8)), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("الإعدادات", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold); Text("المعلومات والمساعدة", color = if (darkMode) Muted else Color.Gray, fontSize = 14.sp) }
        val links = listOf("سياسة الخصوصية" to "privacy", "شروط الاستخدام" to "terms", "سياسة ملفات الارتباط" to "cookies", "إخلاء المسؤولية" to "disclaimer")
        items(links.take(2)) { (title, route) ->
            Row(Modifier.fillMaxWidth().background(cardColor, RoundedCornerShape(12.dp)).clickable { onOpenLegal(route) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = textColor, fontSize = 16.sp, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Gold)
            }
        }
        items(links.drop(2)) { (title, route) ->
            Row(Modifier.fillMaxWidth().background(cardColor, RoundedCornerShape(12.dp)).clickable { onOpenLegal(route) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = textColor, fontSize = 16.sp, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Gold)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(cardColor, RoundedCornerShape(12.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("اتصل بنا", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("صفحتنا الرسمية على فيسبوك", color = textColor, fontSize = 14.sp)
                Text("https://www.facebook.com/share/19q1ZFLDPp/", color = Color(0xFF42C6C2), fontSize = 14.sp, modifier = Modifier.clickable {
                    runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://www.facebook.com/share/19q1ZFLDPp/"))) }
                })
            }
        }
        item { Text("© جميع الحقوق محفوظة — Dramio", color = if (darkMode) Muted else Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
private fun LegalPage(title: String, body: String, darkMode: Boolean) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(body, color = if (darkMode) Color.White else Color(0xFF222222), fontSize = 15.sp, lineHeight = 25.sp)
    }
}
