package com.qisaswahikayat.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private suspend fun uploadAdminFile(uri: Uri, audio: Boolean, idToken: String, context: Context): String = withContext(Dispatchers.IO) {
    val name = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else "file"
    } ?: "file"
    val mime = context.contentResolver.getType(uri) ?: if (audio) "audio/mpeg" else "image/jpeg"
    require(if (audio) name.endsWith(".mp3", true) else mime in listOf("image/jpeg", "image/png", "image/webp")) {
        "اختاري ملف MP3 أو صورة JPG/PNG/WebP"
    }
    val kind = if (audio) "audio" else "story"
    val url = "$API_BASE/api/upload-url?kind=$kind&type=${URLEncoder.encode(mime, "UTF-8")}&filename=${URLEncoder.encode(name, "UTF-8")}"
    val keyResponse = adminRequest(url.removePrefix(API_BASE), idToken, "POST", JSONObject().put("filename", name).put("kind", kind).put("type", mime).toString())
    val key = keyResponse.getString("key")
    val size = context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
    require(size <= if (audio) 100L * 1024 * 1024 else 8L * 1024 * 1024) { "حجم الملف أكبر من الحد المسموح" }
    val connection = URL("$API_BASE/api/upload/${URLEncoder.encode(key, "UTF-8")}").openConnection() as HttpURLConnection
    connection.requestMethod = "PUT"
    connection.doOutput = true
    connection.connectTimeout = 30000
    connection.readTimeout = 120000
    connection.setRequestProperty("Authorization", "Bearer $idToken")
    connection.setRequestProperty("Content-Type", mime)
    if (size > 0L) connection.setFixedLengthStreamingMode(size)
    try {
        val input = context.contentResolver.openInputStream(uri) ?: error("تعذر قراءة الملف")
        input.use { source -> connection.outputStream.use { target -> source.copyTo(target, 64 * 1024) } }
        val code = connection.responseCode
        val response = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
        if (code !in 200..299) throw IllegalStateException(JSONObject(response).optString("error", "فشل رفع الملف"))
    } finally { connection.disconnect() }
    key
}

private fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }

@Composable
private fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Text(value, color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun StudioMetricCard(label: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Panel, RoundedCornerShape(12.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(detail, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun StudioRateBar(label: String, rate: Double, count: Int) {
    val safeRate = rate.coerceIn(0.0, 100.0)
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("${safeRate.toInt()}%  ·  $count", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(8.dp).background(Color.White.copy(alpha = .08f), RoundedCornerShape(8.dp))) {
            Box(Modifier.fillMaxWidth((safeRate / 100.0).toFloat()).fillMaxHeight().background(Gold, RoundedCornerShape(8.dp)))
        }
    }
}

private fun formatStudioDuration(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    val hours = safe / 3600
    val minutes = (safe % 3600) / 60
    val remaining = safe % 60
    return if (hours > 0) "${hours}س ${minutes}د" else if (minutes > 0) "${minutes}د ${remaining}ث" else "${remaining}ث"
}

private fun admobReportStats(report: JSONArray): Triple<Double, Long, Long> {
    var earningsMicros = 0.0
    var impressions = 0L
    var clicks = 0L
    for (i in 0 until report.length()) {
        val item = report.optJSONObject(i) ?: continue
        val row = item.optJSONObject("row") ?: continue
        val metrics = row.optJSONObject("metricValues") ?: continue
        earningsMicros += metrics.optJSONObject("ESTIMATED_EARNINGS")?.optString("microsValue")?.toDoubleOrNull() ?: 0.0
        impressions += metrics.optJSONObject("IMPRESSIONS")?.optString("integerValue")?.toLongOrNull() ?: 0L
        clicks += metrics.optJSONObject("CLICKS")?.optString("integerValue")?.toLongOrNull() ?: 0L
    }
    return Triple(earningsMicros / 1_000_000.0, impressions, clicks)
}

@Composable
fun AdminPanelScreen(idToken: String, adminEmail: String, onClose: () -> Unit, onCatalogChanged: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var loggedIn by remember(idToken, adminEmail) { mutableStateOf(idToken.isNotBlank() && adminEmail.equals("layali.7kayat@gmail.com", true)) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("القصص") }
    var notificationTitle by remember { mutableStateOf("") }
    var notificationBody by remember { mutableStateOf("") }
    var notificationType by remember { mutableStateOf("general") }
    var notificationStoryId by remember { mutableStateOf("") }
    var categories by remember { mutableStateOf(emptyList<JSONObject>()) }
    var stories by remember { mutableStateOf(emptyList<JSONObject>()) }
    var comments by remember { mutableStateOf(emptyList<JSONObject>()) }
    var analytics by remember { mutableStateOf(JSONObject()) }
    var analyticsPeriod by remember { mutableStateOf("28d") }
    var admobReportText by remember { mutableStateOf("") }
    var admobRevenueSummary by remember { mutableStateOf<Triple<Double, Long, Long>?>(null) }
    var editingStory by remember { mutableStateOf<JSONObject?>(null) }
    var storyDialog by remember { mutableStateOf(false) }
    var editingCategory by remember { mutableStateOf<JSONObject?>(null) }
    var categoryDialog by remember { mutableStateOf(false) }
    var editingPart by remember { mutableStateOf<JSONObject?>(null) }
    var partStory by remember { mutableStateOf<JSONObject?>(null) }
    var parts by remember { mutableStateOf(emptyList<JSONObject>()) }
    var partDialog by remember { mutableStateOf(false) }

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var categoryId by remember { mutableStateOf("") }
    var categoryIds by remember { mutableStateOf(setOf<String>()) }
    var status by remember { mutableStateOf("ongoing") }
    var totalEpisodes by remember { mutableStateOf("1") }
    var audioPath by remember { mutableStateOf("") }
    var imagePath by remember { mutableStateOf("") }
    var wideImagePath by remember { mutableStateOf("") }
    var suggestedImagePath by remember { mutableStateOf("") }
    var characterOneName by remember { mutableStateOf("البطلة") }
    var characterTwoName by remember { mutableStateOf("البطل") }
    var characterThreeName by remember { mutableStateOf("شخصية محورية") }
    var characterOneImage by remember { mutableStateOf("") }
    var characterTwoImage by remember { mutableStateOf("") }
    var characterThreeImage by remember { mutableStateOf("") }
    var categoryTitle by remember { mutableStateOf("") }
    var categoryImage by remember { mutableStateOf("") }
    var partTitle by remember { mutableStateOf("") }
    var partAudio by remember { mutableStateOf("") }
    var partImage by remember { mutableStateOf("") }
    var pickerTarget by remember { mutableStateOf("") }

    fun refresh() {
        scope.launch {
            busy = true
            try {
                val catalog = adminRequest("/api/admin/catalog", idToken)
                categories = catalog.optJSONArray("categories")?.objects() ?: emptyList()
                stories = catalog.optJSONArray("stories")?.objects() ?: emptyList()
                comments = adminRequest("/api/admin/comments", idToken).optJSONArray("comments")?.objects() ?: emptyList()
                analytics = adminRequest("/api/admin/analytics?period=$analyticsPeriod", idToken)
                message = "تم تحديث البيانات"
            } catch (e: Exception) { message = e.localizedMessage ?: "تعذر تحديث البيانات" }
            busy = false
        }
    }

    LaunchedEffect(idToken, adminEmail) {
        if (loggedIn) refresh()
    }

    fun resetStory() {
        editingStory = null; title = ""; description = ""; categoryId = categories.firstOrNull { it.optString("slug") != "coming-soon" && it.optString("slug") != "short-stories" }?.optString("id") ?: ""; categoryIds = emptySet()
        status = "ongoing"; totalEpisodes = "1"; audioPath = ""; imagePath = ""; wideImagePath = ""; suggestedImagePath = ""
        characterOneName = "البطلة"; characterTwoName = "البطل"; characterThreeName = "شخصية محورية"
        characterOneImage = ""; characterTwoImage = ""; characterThreeImage = ""
    }
    fun editStory(story: JSONObject?) {
        resetStory(); editingStory = story
        if (story != null) {
            title = story.optString("title"); description = story.optString("description")
            categoryId = story.optString("category_id"); categoryIds = story.optJSONArray("category_ids")?.let { arr -> (0 until arr.length()).map { arr.optString(it) }.toSet() } ?: setOf(categoryId); status = story.optString("status", "ongoing")
            totalEpisodes = story.optString("total_episodes", "1"); audioPath = story.optString("audio_path")
            imagePath = story.optString("image_path"); wideImagePath = story.optString("wide_image_path"); suggestedImagePath = story.optString("suggested_image_path")
            characterOneName = story.optString("character_one_name", "البطلة"); characterTwoName = story.optString("character_two_name", "البطل")
            characterThreeName = story.optString("character_three_name", "شخصية محورية")
            characterOneImage = story.optString("character_one_image_path"); characterTwoImage = story.optString("character_two_image_path")
            characterThreeImage = story.optString("character_three_image_path")
        }
        storyDialog = true
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            try {
                val key = uploadAdminFile(uri, pickerTarget == "audio" || pickerTarget == "partAudio", idToken, context)
                when (pickerTarget) {
                    "audio" -> audioPath = key
                    "image" -> imagePath = key
                    "wide" -> wideImagePath = key
                    "suggested" -> suggestedImagePath = key
                    "characterOne" -> characterOneImage = key
                    "characterTwo" -> characterTwoImage = key
                    "characterThree" -> characterThreeImage = key
                    "category" -> categoryImage = key
                    "partAudio" -> partAudio = key
                    "partImage" -> partImage = key
                }
                message = "تم رفع الملف بنجاح"
            } catch (e: Exception) { message = e.localizedMessage ?: "فشل رفع الملف" }
            busy = false
        }
    }

    fun pick(target: String, audio: Boolean = false) {
        pickerTarget = target
        picker.launch(if (audio) arrayOf("audio/mpeg") else arrayOf("image/*"))
    }

    if (!loggedIn) {
        Column(Modifier.fillMaxSize().background(Ink).safeDrawingPadding().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("لوحة الإدارة", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("يجب تسجيل الدخول من حساب Google المعتمد للمشرف.", color = Muted)
            TextButton(onClick = onClose) { Text("عودة", color = Gold) }
        }
        return
    }

    Column(Modifier.fillMaxSize().background(Ink).safeDrawingPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("إدارة التطبيق", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { refresh() }) { Text("تحديث", color = Gold) }
            TextButton(onClick = onClose) { Text("خروج", color = Gold) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("القصص", "التصنيفات", "التعليقات", "الإشعارات", "الإحصائيات").forEach { label ->
                TextButton(onClick = { tab = label; partStory = null }) { Text(label, color = if (tab == label) Gold else Color.White) }
            }
        }
        when (tab) {
            "الإحصائيات" -> {
                val totals = analytics.optJSONObject("totals") ?: JSONObject()
                val retention = analytics.optJSONObject("retention") ?: JSONObject()
                val comparison = analytics.optJSONObject("comparison")
                val daily = analytics.optJSONArray("daily")?.objects() ?: emptyList()
                val countries = analytics.optJSONArray("countries")?.objects() ?: emptyList()
                val topStories = analytics.optJSONArray("top_stories")?.objects() ?: emptyList()
                val topEpisodes = analytics.optJSONArray("top_episodes")?.objects() ?: emptyList()
                val listenHours = totals.optDouble("listening_hours", 0.0)
                val averageSeconds = totals.optInt("average_listen_seconds")
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Dramio Studio", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("نظرة شاملة على أداء القصص والاستماع والاحتفاظ بالجمهور. كل الأرقام مجمّعة ولا تعرض بيانات مستمع بعينه.", color = Muted, fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf("7d" to "7 أيام", "28d" to "28 يوماً", "90d" to "90 يوماً", "all" to "الكل").forEach { (value, label) ->
                            FilterChip(selected = analyticsPeriod == value, onClick = {
                                analyticsPeriod = value
                                scope.launch { runCatching { analytics = adminRequest("/api/admin/analytics?period=$value", idToken) }.onFailure { message = it.localizedMessage ?: "تعذر تحميل الإحصائيات" } }
                            }, label = { Text(label, fontSize = 11.sp) })
                        }
                    }
                    Text("نظرة عامة", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetricCard("مرات بدء الاستماع", String.format("%,d", totals.optLong("episode_plays")), "بداية تشغيل حلقة", Modifier.weight(1f))
                        StudioMetricCard("ساعات الاستماع", String.format("%.1f", listenHours), "وقت الاستماع المسجل", Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetricCard("متوسط الاستماع", formatStudioDuration(averageSeconds), "لكل مرة بدء استماع", Modifier.weight(1f))
                        StudioMetricCard("إكمال الحلقات", String.format("%,d", totals.optLong("episode_completions")), "حلقات وصلت إلى النهاية", Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetricCard("فتح القصص", String.format("%,d", totals.optLong("story_opens")), "زيارة صفحات القصص", Modifier.weight(1f))
                        StudioMetricCard("إضافات المفضلة", String.format("%,d", totals.optLong("favorite_adds")), "تفاعل القراء", Modifier.weight(1f))
                    }
                    comparison?.let { compare ->
                        val playChange = compare.optDouble("plays_change_percent", Double.NaN)
                        val timeChange = compare.optDouble("listening_change_percent", Double.NaN)
                        val playText = if (playChange.isNaN()) "لا توجد فترة سابقة للمقارنة" else "${if (playChange > 0) "+" else ""}${playChange}%"
                        val timeText = if (timeChange.isNaN()) "—" else "${if (timeChange > 0) "+" else ""}${timeChange}%"
                        Text("مقارنة بالفترة السابقة · مرات الاستماع: $playText · وقت الاستماع: $timeText", color = Muted, fontSize = 11.sp)
                    }

                    Divider(color = Muted.copy(alpha = .35f))
                    Text("الاحتفاظ بالجمهور", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("نسبة جلسات التشغيل التي وصلت إلى كل نقطة من مدة الحلقة. يعتمد القياس على نقاط التقدم التي يسجلها التطبيق أثناء الاستماع.", color = Muted, fontSize = 11.sp)
                    StudioRateBar("وصلوا إلى 25%", retention.optDouble("p25_rate"), retention.optInt("p25"))
                    StudioRateBar("وصلوا إلى 50%", retention.optDouble("p50_rate"), retention.optInt("p50"))
                    StudioRateBar("وصلوا إلى 75%", retention.optDouble("p75_rate"), retention.optInt("p75"))
                    StudioRateBar("أكملوا الحلقة", retention.optDouble("p100_rate"), retention.optInt("p100"))
                    if (retention.optInt("started") == 0) Text("ستظهر نسب الاحتفاظ بعد توفر جلسات تشغيل وبيانات تقدم كافية.", color = Muted, fontSize = 11.sp)

                    Divider(color = Muted.copy(alpha = .35f))
                    Text("اتجاه الاستماع اليومي", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("ساعات الاستماع المسجلة لكل يوم", color = Muted, fontSize = 11.sp)
                    if (daily.isEmpty()) Text("لا توجد بيانات يومية لهذه الفترة حتى الآن.", color = Muted, fontSize = 12.sp)
                    else {
                        val chartRows = daily.takeLast(14)
                        val maxSeconds = (chartRows.maxOfOrNull { it.optLong("listened_seconds") } ?: 0L).coerceAtLeast(1L)
                        Row(Modifier.fillMaxWidth().height(126.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) {
                            chartRows.forEach { point ->
                                val seconds = point.optLong("listened_seconds")
                                val height = (seconds.toFloat() / maxSeconds.toFloat() * 82f).coerceAtLeast(if (seconds > 0) 4f else 2f)
                                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                    Text(if (seconds > 0) String.format("%.1f", seconds / 3600.0) else "0", color = Muted, fontSize = 8.sp, maxLines = 1)
                                    Box(Modifier.width(13.dp).height(height.dp).background(Gold.copy(alpha = .85f), RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)))
                                    Text(point.optString("day").takeLast(5), color = Muted, fontSize = 8.sp, maxLines = 1)
                                }
                            }
                        }
                    }

                    Divider(color = Muted.copy(alpha = .35f))
                    Text("أهم الدول", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("تُستخرج الدولة بشكل تقريبي من بيانات الاتصال، ولا يتم حفظ موقع دقيق.", color = Muted, fontSize = 11.sp)
                    if (countries.isEmpty()) Text("ستظهر الدول بعد تسجيل جلسات الاستماع الجديدة.", color = Muted, fontSize = 12.sp)
                    countries.take(8).forEach { country ->
                        val countryName = country.optString("country").ifBlank { "غير محدد" }
                        StatLine(countryName, "${String.format("%.1f", country.optLong("listened_seconds") / 3600.0)} ساعة · ${country.optInt("plays")} تشغيل")
                    }

                    Divider(color = Muted.copy(alpha = .35f))
                    Text("الإيرادات التقديرية", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("اربط AdMob لعرض الأرباح التقديرية على مستوى التطبيق. لا يمكن توزيعها على قصة محددة من تقرير AdMob القياسي.", color = Muted, fontSize = 11.sp)
                    OutlinedButton(enabled = !busy, onClick = {
                        scope.launch {
                            busy = true
                            try {
                                val auth = adminRequest("/api/admin/admob/oauth/start", idToken, "POST", "{}")
                                val authUrl = auth.optString("authorization_url")
                                require(authUrl.startsWith("https://accounts.google.com/")) { "لم يرجع رابط تفويض صالح" }
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(authUrl)))
                                message = "أكمل موافقة Google في المتصفح، ثم ارجع إلى Dramio"
                            } catch (e: Exception) { message = e.localizedMessage ?: "تعذر بدء ربط AdMob" }
                            busy = false
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("ربط حساب AdMob") }
                    OutlinedButton(enabled = !busy, onClick = {
                        scope.launch {
                            busy = true
                            try {
                                val report = adminRequest("/api/admin/admob/report", idToken)
                                val rows = report.optJSONArray("report") ?: JSONArray()
                                admobRevenueSummary = admobReportStats(rows)
                                admobReportText = "${report.optString("start_date")} — ${report.optString("end_date")}"
                                message = "تم تحميل تقرير AdMob"
                            } catch (e: Exception) { admobReportText = ""; admobRevenueSummary = null; message = e.localizedMessage ?: "تعذر جلب تقرير AdMob" }
                            busy = false
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("تحميل تقرير AdMob لآخر 30 يوماً") }
                    admobRevenueSummary?.let { report ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudioMetricCard("الأرباح التقديرية · USD", String.format("$%.2f", report.first), admobReportText, Modifier.weight(1f))
                            StudioMetricCard("مرات الظهور", String.format("%,d", report.second), "نقرات: ${report.third}", Modifier.weight(1f))
                        }
                        Text("هذه أرباح التطبيق ككل وليست أرباحاً منسوبة إلى قصة بعينها.", color = Muted, fontSize = 10.sp)
                    }

                    Divider(color = Muted.copy(alpha = .35f))
                    Text("أفضل القصص أداءً", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    if (topStories.isEmpty()) Text("ستظهر النتائج بعد تسجيل تفاعلات الاستماع للقصص.", color = Muted, fontSize = 12.sp)
                    topStories.forEachIndexed { index, story ->
                        val plays = story.optInt("plays")
                        val completes = story.optInt("completions")
                        val completionRate = if (plays > 0) completes * 100 / plays else 0
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(11.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("${index + 1}. ${story.optString("title")}", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("تشغيل: $plays · إكمال: $completes · معدل الإكمال: $completionRate%", color = Muted, fontSize = 11.sp)
                            Text("وقت الاستماع: ${String.format("%.1f", story.optLong("listened_seconds") / 3600.0)} ساعة · فتح: ${story.optInt("opens")} · مفضلة: ${story.optInt("favorites")}", color = Gold, fontSize = 11.sp)
                        }
                    }
                    Divider(color = Muted.copy(alpha = .35f))
                    Text("أفضل الحلقات", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    if (topEpisodes.isEmpty()) Text("لا توجد بيانات تشغيل حلقات كافية لهذه الفترة.", color = Muted, fontSize = 12.sp)
                    topEpisodes.forEach { episode ->
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(episode.optString("story_title"), color = Color.White, fontWeight = FontWeight.Bold)
                            Text(episode.optString("episode_title", "الحلقة الأولى"), color = Gold, fontSize = 12.sp)
                            Text("بدء: ${episode.optInt("plays")} · إكمال: ${episode.optInt("completions")} · استماع: ${String.format("%.1f", episode.optLong("listened_seconds") / 3600.0)} ساعة", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
            "الإشعارات" -> {
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("إرسال إشعار لجميع المستخدمين", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("سيظهر الإشعار داخل التطبيق باسم Dramio وبأيقونة التطبيق.", color = Muted, fontSize = 12.sp)
                    OutlinedButton(onClick = {
                        notificationType = if (notificationType == "general") "story_interest" else "general"
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (notificationType == "general") "الهدف: جميع المستخدمين (اضغط للتغيير إلى متابعي قصة)" else "الهدف: متابعو قصة محددة (اضغط للتغيير إلى الجميع)")
                    }
                    if (notificationType == "story_interest") {
                        OutlinedTextField(notificationStoryId, { notificationStoryId = it.filter(Char::isDigit).take(10) },
                            label = { Text("رقم القصة") }, modifier = Modifier.fillMaxWidth(),
                            supportingText = { Text("يرسل فقط للمستخدمين الذين فعّلوا إشعارات هذه القصة") })
                    }
                    OutlinedTextField(notificationTitle, { notificationTitle = it }, label = { Text("عنوان الإشعار") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(notificationBody, { notificationBody = it }, label = { Text("نص الإشعار") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    var selectedTemplate by remember { mutableStateOf("اختر رسالة جاهزة") }
                    val templates = listOf(
                        "رمضان" to ("🌙 رمضان مبارك" to "رمضان كريم من Dramio! نرجو لكم شهراً مليئاً بالخير والحكايات الجميلة."),
                        "العيد" to ("🎉 عيد مبارك" to "كل عام وأنتم بخير! عيد مبارك من Dramio."),
                        "العام الجديد" to ("✨ عام جديد" to "عام جديد سعيد! نتمنى لكم سنة مليئة بالقصص الممتعة."),
                        "العودة" to ("📚 قصة جديدة بانتظارك" to "عد إلى Dramio واكتشف حكاية جديدة تليق بذوقك.")
                    )
                    Text("رسائل موسمية جاهزة", color = Color.White, fontWeight = FontWeight.SemiBold)
                    templates.forEach { (name, pair) ->
                        OutlinedButton(onClick = { selectedTemplate = name; notificationTitle = pair.first; notificationBody = pair.second }, modifier = Modifier.fillMaxWidth()) { Text(name) }
                    }
                    Button(enabled = !busy && notificationTitle.isNotBlank() && notificationBody.isNotBlank() &&
                        (notificationType != "story_interest" || notificationStoryId.toIntOrNull() != null), onClick = {
                        scope.launch {
                            busy = true
                            try {
                                val result = adminRequest("/api/admin/notifications", idToken, "POST", JSONObject().put("title", notificationTitle).put("body", notificationBody).put("type", notificationType)
                                    .put("story_id", notificationStoryId.toIntOrNull() ?: 0).toString())
                                message = "تم الإرسال بنجاح إلى ${result.optInt("push_sent")} جهاز. الهدف: ${if (notificationType == "story_interest") "متابعو القصة" else "جميع المستخدمين"}."
                                notificationTitle = ""; notificationBody = ""; notificationStoryId = ""
                            } catch (e: Exception) { message = e.localizedMessage ?: "تعذر إرسال الإشعار" }
                            busy = false
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("إرسال للمستخدمين") }
                    if (message.isNotBlank()) Text(message, color = Gold, fontSize = 12.sp)
                }
            }
            "القصص" -> {
                if (partStory != null) {
                    Column(Modifier.weight(1f).padding(12.dp)) {
                        Text("فصول: ${partStory?.optString("title")}", color = Gold, fontSize = 19.sp)
                        Button(onClick = { editingPart = null; partTitle = ""; partAudio = ""; partImage = ""; partDialog = true }) { Text("إضافة فصل") }
                        LazyColumn {
                            items(parts, key = { it.optString("id") }) { part ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(10.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(part.optString("title"), color = Color.White, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { editingPart = part; partTitle = part.optString("title"); partAudio = part.optString("audio_path"); partImage = part.optString("image_path"); partDialog = true }) { Text("تعديل", color = Gold) }
                                    TextButton(onClick = {
                                        scope.launch { runCatching { adminRequest("/api/admin/part/${part.optString("id")}", idToken, "DELETE"); parts = loadParts(partStory!!, idToken) }.onFailure { message = it.localizedMessage ?: "تعذر الحذف" } }
                                    }) { Text("حذف", color = Color(0xFFFF8A80)) }
                                }
                            }
                        }
                        TextButton(onClick = { partStory = null }) { Text("رجوع للقصص", color = Gold) }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("القصص (${stories.size})", color = Gold); Spacer(Modifier.weight(1f))
                        Button(onClick = { editStory(null) }) { Text("إضافة قصة") }
                    }
                    LazyColumn(Modifier.weight(1f)) {
                        items(stories, key = { it.optString("id") }) { story ->
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp).background(Panel, RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(story.optString("title"), color = Color.White, fontWeight = FontWeight.Bold)
                                    Text(if (story.optString("status") == "completed") "مكتملة" else "مستمرة", color = Gold, fontSize = 12.sp)
                                }
                                val storyCategoryIds = story.optJSONArray("category_ids")?.let { ids -> (0 until ids.length()).map { index -> ids.optString(index) } } ?: emptyList()
                                val shortCategoryId = categories.firstOrNull { it.optString("slug") == "short-stories" }?.optString("id")
                                val isShortStory = shortCategoryId != null && shortCategoryId in storyCategoryIds
                                if (!isShortStory) {
                                    TextButton(onClick = { partStory = story; scope.launch { runCatching { parts = loadParts(story, idToken) }.onFailure { message = it.localizedMessage ?: "تعذر تحميل الفصول" } } }) { Text("الفصول", color = Gold) }
                                } else {
                                    Text("حلقة واحدة", color = Muted, fontSize = 10.sp)
                                }
                                TextButton(onClick = { editStory(story) }) { Text("تعديل", color = Gold) }
                                TextButton(onClick = { scope.launch { runCatching { adminRequest("/api/admin/story/${story.optString("id")}", idToken, "DELETE"); refresh() }.onFailure { message = it.localizedMessage ?: "تعذر الحذف" } } }) { Text("حذف", color = Color(0xFFFF8A80)) }
                            }
                        }
                    }
                }
            }
            "التصنيفات" -> {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text("التصنيفات (${categories.size})", color = Gold); Spacer(Modifier.weight(1f)); Button(onClick = { editingCategory = null; categoryTitle = ""; categoryImage = ""; categoryDialog = true }) { Text("إضافة") } }
                LazyColumn(Modifier.weight(1f)) {
                    items(categories, key = { it.optString("id") }) { category ->
                        Row(Modifier.fillMaxWidth().padding(8.dp).background(Panel, RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(category.optString("title"), color = Color.White, modifier = Modifier.weight(1f))
                            if (category.optString("slug") in setOf("coming-soon", "short-stories")) {
                                Text("تصنيف أساسي", color = Muted, fontSize = 10.sp)
                                TextButton(onClick = { editingCategory = category; categoryTitle = category.optString("title"); categoryImage = category.optString("image_path"); categoryDialog = true }) { Text("تعديل الصورة", color = Gold) }
                            } else {
                                TextButton(onClick = { editingCategory = category; categoryTitle = category.optString("title"); categoryImage = category.optString("image_path"); categoryDialog = true }) { Text("تعديل", color = Gold) }
                                TextButton(onClick = { scope.launch { runCatching { adminRequest("/api/admin/category/${category.optString("id")}", idToken, "DELETE"); refresh() }.onFailure { message = it.localizedMessage ?: "تعذر الحذف" } } }) { Text("حذف", color = Color(0xFFFF8A80)) }
                            }
                        }
                    }
                }
            }
            else -> {
                Text("التعليقات (${comments.size})", color = Gold, modifier = Modifier.padding(12.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(comments, key = { it.optString("id") }) { comment ->
                        Column(Modifier.fillMaxWidth().padding(8.dp).background(Panel, RoundedCornerShape(10.dp)).padding(12.dp)) {
                            Text("تعليق", color = Gold)
                            Text(comment.optString("content"), color = Color.White)
                            Text(comment.optString("story_title"), color = Muted, fontSize = 12.sp)
                            TextButton(onClick = { scope.launch { runCatching { adminRequest("/api/admin/comment/${comment.optString("id")}", idToken, "DELETE"); refresh() }.onFailure { message = it.localizedMessage ?: "تعذر الحذف" } } }) { Text("حذف التعليق", color = Color(0xFFFF8A80)) }
                        }
                    }
                }
            }
        }
        if (message.isNotBlank()) Text(message, color = if (message.contains("تعذر") || message.contains("فشل")) Color(0xFFFF8A80) else Gold, modifier = Modifier.padding(10.dp))
    }

    val shortStoryCategorySelected = categories.any { category ->
        category.optString("slug") == "short-stories" && category.optString("id") in categoryIds
    }

    if (storyDialog) AlertDialog(
        onDismissRequest = { storyDialog = false },
        title = { Text(if (editingStory == null) "إضافة قصة" else "تعديل القصة") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                item {
                    OutlinedTextField(title, { title = it }, label = { Text("عنوان القصة") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(description, { description = it }, label = { Text("الوصف") }, modifier = Modifier.fillMaxWidth())
                    if (!shortStoryCategorySelected) {
                        OutlinedTextField(totalEpisodes, { totalEpisodes = it }, label = { Text("عدد الحلقات") }, modifier = Modifier.fillMaxWidth())
                    } else {
                        Text("قصة قصيرة مكتملة في حلقة واحدة، لن يظهر عدد الحلقات للمستخدمين.", color = Gold, fontSize = 12.sp)
                    }
                    Text("التصنيف", color = Gold)
                    categories.filter { it.optString("slug") != "coming-soon" }.forEach { category ->
                        val id = category.optString("id")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = id in categoryIds, onCheckedChange = { checked ->
                                categoryIds = if (checked) categoryIds + id else categoryIds - id
                                if (category.optString("slug") == "short-stories" && checked) { totalEpisodes = "1"; status = "completed" }
                            })
                            Text(category.optString("title"), color = Color.White)
                        }
                    }
                    Text("إذا لم تضف ملف MP3 فستظهر القصة تلقائياً في تصنيف قريباً.", color = Muted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(status == "ongoing", { status = "ongoing" }); Text("مستمرة", color = Color.White); RadioButton(status == "completed", { status = "completed" }); Text("مكتملة", color = Color.White) }
                }
                item { UploadRow("ملف الصوت MP3", audioPath, { pick("audio", true) }) }
                item { UploadRow("صورة الغلاف (3:4)", imagePath, { pick("image") }) }
                item { UploadRow("الصورة العريضة (1:1)", wideImagePath, { pick("wide") }) }
                item { UploadRow("صورة القصص المقترحة (16:9)", suggestedImagePath, { pick("suggested") }) }
                item { OutlinedTextField(characterOneName, { characterOneName = it }, label = { Text("اسم البطلة") }); UploadRow("صورة البطلة", characterOneImage, { pick("characterOne") }) }
                item { OutlinedTextField(characterTwoName, { characterTwoName = it }, label = { Text("اسم البطل") }); UploadRow("صورة البطل", characterTwoImage, { pick("characterTwo") }) }
                item { OutlinedTextField(characterThreeName, { characterThreeName = it }, label = { Text("اسم الشخصية المحورية") }); UploadRow("صورة الشخصية المحورية", characterThreeImage, { pick("characterThree") }) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && title.isNotBlank() && imagePath.startsWith("images/") &&
                (audioPath.startsWith("audio/") || !shortStoryCategorySelected), onClick = {
                scope.launch {
                    busy = true
                    try {
                        val chosenCategories = if (categoryIds.isNotEmpty()) categoryIds else setOf(categoryId).filter { it.isNotBlank() }.toSet()
                        require(chosenCategories.isNotEmpty()) { "اختاري تصنيفًا واحدًا على الأقل" }
                        val body = JSONObject().put("title", title).put("description", description).put("category_id", chosenCategories.first()).put("category_ids", JSONArray(chosenCategories.toList()))
                            .put("audio_path", audioPath).put("image_path", imagePath).put("wide_image_path", wideImagePath).put("suggested_image_path", suggestedImagePath)
                            .put("total_episodes", if (shortStoryCategorySelected) 1 else (totalEpisodes.toIntOrNull() ?: 1))
                            .put("status", if (shortStoryCategorySelected) "completed" else status)
                            .put("character_one_name", characterOneName).put("character_two_name", characterTwoName).put("character_three_name", characterThreeName)
                            .put("character_one_image_path", characterOneImage).put("character_two_image_path", characterTwoImage).put("character_three_image_path", characterThreeImage)
                        if (editingStory == null) adminRequest("/api/admin/story", idToken, "POST", body.toString())
                        else adminRequest("/api/admin/story/${editingStory!!.optString("id")}", idToken, "PUT", body.toString())
                        storyDialog = false; refresh(); onCatalogChanged()
                    } catch (e: Exception) { message = e.localizedMessage ?: "تعذر حفظ القصة" }
                    busy = false
                }
            }) { Text("حفظ") }
        }, dismissButton = { TextButton(onClick = { storyDialog = false }) { Text("إلغاء") } }
    )

    if (categoryDialog) AlertDialog(
        onDismissRequest = { categoryDialog = false }, title = { Text(if (editingCategory == null) "إضافة تصنيف" else "تعديل التصنيف") },
        text = { Column {
            val isBuiltInCategory = editingCategory?.optString("slug") in setOf("coming-soon", "short-stories")
            OutlinedTextField(categoryTitle, { categoryTitle = it }, label = { Text("اسم التصنيف") }, readOnly = isBuiltInCategory,
                supportingText = { if (isBuiltInCategory) Text("يمكنك تغيير الصورة مع الحفاظ على اسم التصنيف الأساسي") })
            UploadRow("صورة التصنيف", categoryImage, { pick("category") })
        } },
        confirmButton = { TextButton(onClick = {
            scope.launch {
                busy = true
                try {
                    val body = JSONObject().put("title", categoryTitle).put("image_path", categoryImage)
                    if (editingCategory == null) adminRequest("/api/admin/category", idToken, "POST", body.toString())
                    else adminRequest("/api/admin/category/${editingCategory!!.optString("id")}", idToken, "PUT", body.toString())
                    categoryDialog = false; refresh()
                } catch (e: Exception) { message = e.localizedMessage ?: "تعذر حفظ التصنيف" }
                busy = false
            }
        }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { categoryDialog = false }) { Text("إلغاء") } }
    )

    if (partDialog) AlertDialog(
        onDismissRequest = { partDialog = false }, title = { Text(if (editingPart == null) "إضافة فصل" else "تعديل الفصل") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(partTitle, { partTitle = it }, label = { Text("عنوان الفصل") }, modifier = Modifier.fillMaxWidth()); UploadRow("ملف MP3", partAudio, { pick("partAudio", true) }); UploadRow("صورة الفصل", partImage, { pick("partImage") }) } },
        confirmButton = { TextButton(enabled = !busy && partTitle.isNotBlank() && (partAudio.startsWith("audio/") || editingPart != null), onClick = {
            scope.launch {
                busy = true
                try {
                    val body = JSONObject().put("title", partTitle).put("audio_path", partAudio).put("image_path", partImage)
                    if (editingPart == null) adminRequest("/api/admin/story/${partStory!!.optString("id")}/parts", idToken, "POST", body.toString())
                    else adminRequest("/api/admin/part/${editingPart!!.optString("id")}", idToken, "PUT", body.toString())
                    partDialog = false; editingPart = null; parts = loadParts(partStory!!, idToken)
                } catch (e: Exception) { message = e.localizedMessage ?: "تعذر حفظ الفصل" }
                busy = false
            }
        }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { partDialog = false }) { Text("إلغاء") } }
    )
}

private suspend fun loadParts(story: JSONObject, idToken: String): List<JSONObject> {
    return adminRequest("/api/admin/story/${story.optString("id")}/parts", idToken).optJSONArray("parts")?.objects() ?: emptyList()
}

@Composable
private fun UploadRow(label: String, value: String, onPick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = onPick) { Text(label) }
        Spacer(Modifier.width(8.dp))
        Text(if (value.isBlank()) "لم يتم الاختيار" else value.substringAfterLast('/'), color = Muted, fontSize = 11.sp, maxLines = 1)
    }
}
